Assignment 1：红色、蓝色、绿色检测完整 Arduino 工程

使用步骤
1. 完整解压，打开文件夹内 ESP32_CameraServer_AP_20220120.ino。不要只复制 .ino。
2. 使用此前成功的开发环境：esp32 by Espressif Systems 1.0.4，ESP32 Dev Module，
   Partition Scheme: Huge APP (3MB No OTA/1MB SPIFFS)，PSRAM: Enabled。
3. 选择摄像头对应 COM 端口，点击上传箭头（不仅是编译勾号）。上传成功后按 Reset。
4. Wi-Fi 使用最后截图中的配置：Wifi121381345，密码 121381345，信道 9。
   如需更改，在 CameraWebServer_AP.cpp 中编辑 ap_ssid / ap_password，然后重新上传。
5. 手机或电脑连接该 Wi-Fi，打开 http://192.168.4.1/。
6. 在网页选择 QVGA 320x240 或 240x176，再点击 Start Stream。
   保留原来的相机默认分辨率；图像宽度大于 400 时跳过颜色和人脸检测。
7. 串口监视器设为 9600 baud。默认颜色检测开启，约每 2 秒输出一次英文结果。

新增内容
- color_blob.h：增加 TARGET_GREEN、is_green_pixel、find_green_blob。
- 绿色 HSV 阈值：色相 120°±20°，饱和度至少 45%，亮度至少 60/255。
- 红色为 0°±20°，蓝色为 240°±20°。三种颜色分别选择最大四连通区域。
- 过滤小于 100 像素的区域。中心为区域像素平均坐标，面积为像素数量。
- app_httpd.cpp：新增绿色检测结果、英文报告、绿色分析耗时及目标框。
- 三种颜色复用同一份 mask 和 queue，不额外分配第三份工作区。
- 完成所有颜色分析和人脸识别后再绘制，避免标记污染颜色输入。
- Wi-Fi 从旧压缩包中的较早值同步为你最后截图中的设置。

结果说明
Target color: Red / Blue / Green，分别代表三种目标颜色。
Center position: X, Y，单位像素，原点左上，X 向右、Y 向下。
Target area: 区域像素数，不等于外接框面积或实际物体尺寸。
Target coverage: 区域像素数除以总像素数。
Bounding box: Left / Top / Right / Bottom 为包含边界的像素坐标。
No valid target detected: 没有满足阈值且达到最小面积的区域。
三个目标都用绿色框和十字标记；串口通过 Red / Blue / Green 标签区分。
Combined blob analysis time 包括三个颜色的分析，不包括分配、解码、绘制、
日志、JPEG 编码和网络传输时间。

颜色检测独立开关
开：http://192.168.4.1/control?var=color_detect&val=1
关：http://192.168.4.1/control?var=color_detect&val=0
这是三种颜色共同的开关，不自动关闭人脸功能。
保持原 camera_index.h，因此网页没有新增按钮。可在另一个浏览器标签页访问以上链接。
颜色识别仅集成到实时视频流，Get Still 接口保持原功能。
原有人脸检测和识别保留；同时运行会增加处理时间，帧率可能降低。
9600 baud 的长串口输出也会影响帧率。

测试建议
- 同时放红、蓝、绿物体：串口应分别报告三个结果。
- 移走绿色：Green 应显示 No valid target detected，其他颜色继续工作。
- 放两个绿色物体：应选择像素面积最大的绿色区域。
- 上下左右移动绿色物体：确认中心坐标随之变化。
- 关闭颜色开关：颜色框与报告停止，人脸功能保持自己的开关状态。
- 若红蓝颠倒，将 color_blob.h 中 COLOR_INPUT_BGR 从 1 改为 0，再上传。
- 绿色阈值不包含所有青色、黄色或低饱和度的浅绿色，光照会影响结果。

验证范围
主机 C++ 合成图像算法测试通过：红蓝绿分离、绿色阈值过滤、最大区域、
质心、边界、最小面积、四连通、分析不修改原图以及边缘绘制。
当前环境没有 Arduino ESP32 工具链，未完成整套固件编译或摄像头实机测试。
本包包含完整 Arduino 源码，无旧 .bin，需自行编译上传。
VS Code 的 JSON 编辑器配置不是 Arduino IDE 编译依赖，不包含在本包中。
