# YOLO FAST 12: raw candidate diagnostic

## Install
1. Close Arduino IDE. Move the old A2_StopSign_YOLO_104 folder outside Arduino/libraries.
2. Install Arduino_Libraries/A2_StopSign_YOLO_104.zip from THIS package. FAST12 requires its diagnostic hook even if FAST11 is already installed. The model weights are unchanged.
3. Upload ESP32_Assignment2/ESP32_Assignment2.ino using ESP32 Dev Module, ESP32 core 1.0.4, Huge APP, 4MB flash, PSRAM Enabled, CPU 240MHz. Existing matching UNO firmware needs no update.
4. Refresh http://192.168.4.1/ and confirm YOLO FAST 12.

## Measure
Keep the car stationary. Leave AI enabled, Preview off, CIF, Centre crop, display threshold 70%.
At 20, 30, 40 and 50 cm, capture 3 distinct frames per distance. Also capture several frames without a sign.
Click Training photos > Capture new frame. The yellow dashed box on the captured model input marks the highest STOP-class candidate BEFORE the internal 50% score filter and NMS.
Compare the yellow box with the actual sign. A high raw score on a background object is not a STOP detection.
Save original JPEG, model input BMP, and metadata from the same capture. Name folders 20cm, 30cm, 40cm, 50cm, and background. Metadata contains raw_diagnostic (x,y,w,h in 96x96 model coordinates).
For 30-50 cm, repeat with 2x centre crop while keeping the sign within the crop.
Raw scores do not enter normal detections, calibration, or the UNO protocol. The internal 50%, display 70% default, and UNO 80% confidence gates are unchanged. There is no second inference and no continuous image-copy operation.
This build diagnoses confidence/location; it does not claim improved accuracy, distance or inference speed.

## BMP upload error
If an upload service rejects BMP with Invalid mimetype (application/octet-stream), use the original JPEG or convert BMP to PNG without resizing. Do not just rename the extension.
Optional PC conversion: install Pillow (`python -m pip install pillow`), then `python PC_Tools/bmp_to_png.py YOUR_IMAGE_FOLDER`.
Converted PNGs preserve the RGB pixels. For testing the current 96x96 model, preserve its color and preprocessing settings. For new training, prefer original JPEGs with bounding boxes around the full sign.

## Validation
ESP32 Arduino core 1.0.4 compile: 1,660,922 / 3,145,728 bytes flash; 63,944 bytes static RAM.
Synthetic raw-observer test: lower-than-50% scores, label filtering, max selection, invalid score rejection, and per-frame reset.
Browser mock: 42% raw candidate, same-capture overlay, unavailable/invalid status, threshold apply, capture, preview, calibration sample/save/clear/error, mobile layout.
Hardware latency, accuracy and network behavior have not been measured for FAST12.
