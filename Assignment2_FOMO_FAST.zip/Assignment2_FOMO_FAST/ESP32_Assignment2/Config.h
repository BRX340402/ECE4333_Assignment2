#pragma once
#include <stdint.h>
#define A2_ENABLE_AI 1
#define A2_MODEL_HEADER "A2_StopSign_FOMO_104.h"
#define COLOR_INPUT_BGR 1 // legacy decoder order; verify with a red/blue object
#define CAMERA_MODEL_M5STACK_WIDE
static const char *AP_SSID = "ECE4333_A2_V2";
static const char *AP_PASSWORD = "12345678";
static const int AP_CHANNEL = 9;
static const int UART_RX = 33, UART_TX = 4;
static const int IMAGE_W = 400, IMAGE_H = 296;
static const float AI_THRESHOLD = 0.70f;
static const uint32_t FRAME_INTERVAL_MS = 10;
// Legacy constants retained for source compatibility. FullUI3 calibration is
// managed by /calibrate and NVS a2-cam-v2; do not edit these to calibrate.
static const float STOP_K = 0.0f;
static const float RED_LIGHT_K = 0.0f;
static const float GREEN_LIGHT_K = 0.0f;
static const float CONE_K = 0.0f;
static const int BLACK_MAX = 65; // bottom 1/4 image, must be tuned to actual floor

// 0: multiline Serial Monitor; 1: numeric Serial Plotter; 2: JSON lines.
#define A2_SERIAL_MODE 1

// FAST build: face support removed.
#define A2_ENABLE_LEGACY_FACE 0

// Reserve model arena in internal RAM when enough memory remains. 0 forces PSRAM.
#define A2_INTERNAL_ARENA 1
