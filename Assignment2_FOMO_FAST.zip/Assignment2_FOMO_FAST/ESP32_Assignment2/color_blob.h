#pragma once
#include <stdint.h>
struct ColorBlob {int x,y,x0,y0,x1,y1;uint32_t pixels;};
