#include "ResultTiming.h"
#include <Arduino.h>
#include <atomic>
#include <Preferences.h>
#include <cmath>
#include "Config.h"
#include <WiFi.h>
#include <WebServer.h>
#include "esp_camera.h"
#include "img_converters.h"
#include "camera_pins.h"
#include "freertos/semphr.h"
#include "freertos/queue.h"
#include <esp_heap_caps.h>
#include "CameraDecode.h"
#include "AIAdapter.h"
#include "WebPage.h"
#include "CaptureCheck.h"
#include "RedCamera.h"
#include "JpegSize.h"
WebServer web(80);
int analysisW=400,analysisH=296;
bool inputBGR=true;
ViewMap aiView=makeView(400,296,1,500,500);
int viewMode=1,viewCx=500,viewCy=500;
float aiThreshold=AI_THRESHOLD,bestScore=0;
std::atomic<int> pendingThreshold{-1};
std::atomic<int> pendingResolution{-1};
std::atomic<bool> resolutionBusy{false};
uint32_t resolutionId=0;int requestedResolution=5;
String resolutionState="idle",resolutionMessage="No resolution change requested";
int verifiedWidth=400,verifiedHeight=296;
int stopCount=0,photoW=400,photoH=296;
uint8_t *completedJpeg=nullptr;size_t completedLen=0;
bool inputReady=false;
int calibrationResolution=5;
uint16_t geometryEpoch=0;
String cameraStatus="{}";

Preferences calibration;
bool calibrationReady=false;
float distanceK[5]={STOP_K,0,0,0,0}; // stop, red, blue, green, orange
int calibrationSlot(int id){return id==1?0:(id>=6&&id<=9?id-5:-1);}
const char *calibrationKeys[5]={"stop_fomo6","red","blue","green","orange"};
bool usableSize(const ColorBlob &b){return b.pixels && b.x1-b.x0+1>=6 && b.x0>0 && b.y0>0 && b.x1<analysisW-1 && b.y1<analysisH-1;}

struct Detection { ColorBlob box;int color,id,distance;float confidence;uint32_t inference_ms;int aiX,aiY; const char *sizeReason;int borderRays,textPixels;bool sizeOk; } detections[8];
uint8_t *rgb=nullptr;
void prepareEiArena();bool eiArenaInternal();
uint32_t decodeMs=0,cycleMs=0;
std::atomic<bool> previewEnabled{false};
camera_fb_t *frame=nullptr;
uint8_t objectCount=0;uint16_t sequence=0;
bool cameraOK=false,rgbOK=false;int aiError=0;
bool frameValid=false;int lineX=-1;bool lineValid=false;
uint32_t nextFrame=0,captureMs=0,processMs=0,totalInferenceMs=0,frameTime=0,dspMs=0,nnMs=0;
SemaphoreHandle_t frameMutex,stateMutex,cameraMutex,decoderMutex;
struct RedStatus {bool valid=false,seen=false;uint32_t captured=0,ms=0;RedRegion region;};
RedStatus redStatus;
std::atomic<int> redMinPixels{12};
uint8_t *redCells=nullptr;uint16_t *redQueue=nullptr;
camera_fb_t copiedFrame={};
void releaseFrame(){if(frame){free(frame->buf);frame=nullptr;}}
camera_fb_t *copyCameraFrame(){
 xSemaphoreTake(cameraMutex,portMAX_DELAY);camera_fb_t *src=esp_camera_fb_get();camera_fb_t *out=nullptr;
 if(src){copiedFrame=*src;copiedFrame.buf=(uint8_t*)ps_malloc(src->len);if(copiedFrame.buf){memcpy(copiedFrame.buf,src->buf,src->len);out=&copiedFrame;}esp_camera_fb_return(src);}
 xSemaphoreGive(cameraMutex);return out;
}

QueueHandle_t visionQueue;
String cachedResults="{\"seq\":0,\"ai\":0,\"objects\":[]}",unoStatus="{}",lastReply="";
uint32_t lastUno=0;
std::atomic<bool> detectEnabled{true},colorEnabled{true};

String unoRx;
uint32_t appLastSeen=0,appHeartbeat=0;
int owner=0; // 0 none/local, 1 browser, 2 official APP
struct VisionPayload { uint16_t seq;bool ai,valid;int confidence,distance,cx,cy,w,h;uint32_t captured;bool observed;uint32_t completed; };
void sendJSON(const String &s){Serial2.println(s);}
int distanceFor(int id,const ColorBlob &b){
  int slot=calibrationSlot(id);
  float k=slot>=0?distanceK[slot]:0;
  int w=b.x1-b.x0+1;
  if(k<=0 || !usableSize(b))return -1;
  float d=k*analysisW/w;if(!std::isfinite(d)||d>10000)return -1;return (int)(d+0.5f);
}
void publish(){
  VisionPayload v={sequence,(bool)A2_ENABLE_AI,frameValid,0,-1,-1,-1,0,0,frameTime,false,millis()};
  if(!detectEnabled)v.ai=false;
  for(int i=0;i<objectCount;i++){
    Detection &d=detections[i];
    if(d.id==1 && d.confidence*1000>v.confidence){
      v.observed=frameValid&&detectEnabled;
      v.confidence=(int)(d.confidence*1000);v.distance=d.distance;
      v.cx=d.box.x;v.cy=d.box.y;v.w=d.box.x1-d.box.x0+1;v.h=d.box.y1-d.box.y0+1;
    }
  }
  xQueueOverwrite(visionQueue,&v);
}
String results(){
  String s;s.reserve(3500);
  s="{\"seq\":"+String(sequence)+",\"device_ms\":"+String(frameTime)+",\"ai\":"+String(A2_ENABLE_AI)+",\"valid\":"+String(frameValid);
  s+=",\"frame_age_ms\":"+String(millis()-frameTime)+",\"capture_ms\":"+String(captureMs)+",\"process_ms\":"+String(processMs);
  s+=",\"dsp_ms\":"+String(dspMs)+",\"nn_ms\":"+String(nnMs);
  s+=",\"inference_ms\":"+String(totalInferenceMs)+",\"heap_free\":"+String(ESP.getFreeHeap())+",\"psram_free\":"+String(ESP.getFreePsram());
  s+=",\"decode_ms\":"+String(decodeMs)+",\"cycle_ms\":"+String(cycleMs)+",\"arena_internal\":"+String(eiArenaInternal())+",\"preview_enabled\":"+String((bool)previewEnabled);
  s+=",\"line_x\":"+String(lineX)+",\"line_valid\":"+String(lineValid)+",\"objects\":[";
  for(int i=0;i<objectCount;i++){
    Detection &d=detections[i];ColorBlob &b=d.box;if(i)s+=',';
    s+="{\"index\":"+String(i)+",\"color\":"+String(d.color)+",\"id\":"+String(d.id)+",\"label\":\""+className(d.id)+"\",\"confidence\":"+String(d.confidence,4);
    s+=",\"cx\":"+String(b.x)+",\"cy\":"+String(b.y)+",\"x\":"+String(b.x0)+",\"y\":"+String(b.y0)+",\"w\":"+String(b.x1-b.x0+1)+",\"h\":"+String(b.y1-b.y0+1);
    bool measured=d.sizeOk;int slot=calibrationSlot(d.id);
    const char *reason=!measured?(d.sizeReason?d.sizeReason:"no_matched_red_region"):(!usableSize(b)?"clipped_or_too_small":(slot<0||distanceK[slot]<=0?"not_calibrated":(d.distance<0?"out_of_range":"ok")));
    s+=",\"ai_cx\":"+String(d.aiX)+",\"ai_cy\":"+String(d.aiY);
    s+=",\"size_source\":\""+String(d.id==1?("yolo_box"):"colour_region")+"\",\"size_valid\":"+String(d.sizeOk&&usableSize(b));
    s+=",\"distance_valid\":"+String(d.distance>=0)+",\"distance_reason\":\""+reason+"\"";
    s+=",\"border_rays\":"+String(d.borderRays)+",\"text_pixels\":"+String(d.textPixels);
    s+=",\"pixels\":"+String(b.pixels)+",\"distance_cm\":"+String(d.distance)+",\"inference_ms\":"+String(d.inference_ms)+"}";
  }
  s+="],\"camera_ok\":"+String(cameraOK)+",\"rgb_ok\":"+String(rgbOK)+",\"ai_error\":"+String(aiError);
  s+=",\"heap_largest\":"+String(heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT));
  s+=",\"image_w\":"+String(analysisW)+",\"image_h\":"+String(analysisH)+",\"photo_w\":"+String(photoW)+",\"photo_h\":"+String(photoH);
  s+=",\"best_score\":"+String(bestScore,4)+",\"threshold\":"+String(aiThreshold,2)+",\"model_min_score\":0.5,\"stop_count\":"+String(stopCount);
  s+=",\"raw_diagnostic\":{\"available\":"+String(rawDiagnostic.available&&frameValid&&detectEnabled)+",\"count\":"+String(rawDiagnostic.count);
  s+=",\"score\":"+String(rawDiagnostic.score,6)+",\"x\":"+String(rawDiagnostic.x,3)+",\"y\":"+String(rawDiagnostic.y,3);
  s+=",\"w\":"+String(rawDiagnostic.w,3)+",\"h\":"+String(rawDiagnostic.h,3)+",\"space\":\"model_160x160\",\"before_score_filter_and_merging\":true,\"kind\":\"fomo_cell\"}";
  s+=",\"roi\":{\"x\":"+String(aiView.x)+",\"y\":"+String(aiView.y)+",\"w\":"+String(aiView.w)+",\"h\":"+String(aiView.h)+"}";
  s+=",\"framesize\":"+String((int)esp_camera_sensor_get()->status.framesize)+",\"epoch\":"+String(geometryEpoch)+",\"calibration_k\":[";
  for(int i=0;i<5;i++){if(i)s+=',';s+=String(distanceK[i],2);}
  return s+"]}";
}
void acquire(){
 uint32_t start=millis();frameValid=false;objectCount=0;lineValid=false;lineX=-1;sequence++;
 decodeMs=0;totalInferenceMs=0;dspMs=nnMs=0;aiError=0;cameraOK=false;rgbOK=false;bestScore=0;stopCount=0;rawDiagnostic={};
 releaseFrame();
 frame=copyCameraFrame();frameTime=millis();captureMs=millis()-start;
 cameraOK=frame && frame->format==PIXFORMAT_JPEG && frame->len>0;
 if(cameraOK){photoW=frame->width;photoH=frame->height;}
 uint32_t ds=millis();
 xSemaphoreTake(decoderMutex,portMAX_DELAY);
 bool decoded=cameraOK && decodeModelInput(frame,rgb,analysisW,analysisH,aiView,viewMode,viewCx,viewCy);
 xSemaphoreGive(decoderMutex);
 if(!decoded){inputReady=false;processMs=millis()-start;publish();return;}
 decodeMs=millis()-ds;rgbOK=true;frameValid=true;aiPixels=rgb;inputReady=true;
 StopPrediction stop={};
 if(detectEnabled){if(!inferFrame(rgb,stop))frameValid=false;totalInferenceMs=stop.duration;dspMs=stop.dspMs;nnMs=stop.nnMs;aiError=stop.error;bestScore=stop.best;}
 stopCount=stop.count;
 for(int i=0;i<stop.count;i++){
  Detection &d=detections[objectCount++];d.box=stop.box[i];d.color=0;d.id=1;d.confidence=stop.confidence[i];d.inference_ms=stop.duration;d.distance=-1;d.aiX=stop.box[i].x;d.aiY=stop.box[i].y;
  d.sizeOk=false;d.sizeReason="FOMO_centroid_has_no_object_size";
  d.borderRays=d.textPixels=0;if(d.sizeOk)d.distance=distanceFor(1,d.box);
 }
 processMs=millis()-start;publish();
}

bool cameraInit(){
  camera_config_t c={};c.ledc_channel=LEDC_CHANNEL_0;c.ledc_timer=LEDC_TIMER_0;
  c.pin_d0=Y2_GPIO_NUM;c.pin_d1=Y3_GPIO_NUM;c.pin_d2=Y4_GPIO_NUM;c.pin_d3=Y5_GPIO_NUM;
  c.pin_d4=Y6_GPIO_NUM;c.pin_d5=Y7_GPIO_NUM;c.pin_d6=Y8_GPIO_NUM;c.pin_d7=Y9_GPIO_NUM;
  c.pin_xclk=XCLK_GPIO_NUM;c.pin_pclk=PCLK_GPIO_NUM;c.pin_vsync=VSYNC_GPIO_NUM;c.pin_href=HREF_GPIO_NUM;
  c.pin_sscb_sda=SIOD_GPIO_NUM;c.pin_sscb_scl=SIOC_GPIO_NUM;c.pin_pwdn=PWDN_GPIO_NUM;c.pin_reset=RESET_GPIO_NUM;
  c.xclk_freq_hz=10000000;c.pixel_format=PIXFORMAT_JPEG;c.frame_size=FRAMESIZE_UXGA;c.jpeg_quality=12;c.fb_count=1;
  if(esp_camera_init(&c)!=ESP_OK)return false;
  sensor_t*s=esp_camera_sensor_get();s->set_framesize(s,FRAMESIZE_CIF);s->set_vflip(s,0);s->set_hmirror(s,0);
  s->set_special_effect(s,0);s->set_whitebal(s,1);s->set_awb_gain(s,1);s->set_wb_mode(s,0);
  s->set_exposure_ctrl(s,1);s->set_gain_ctrl(s,1);s->set_saturation(s,0);
  return true;
}
void loadCalibration(int resolution){
 calibrationResolution=resolution;for(int i=0;i<5;i++)distanceK[i]=0;
 if(calibrationReady && calibration.getInt("res",-1)==resolution)for(int i=0;i<5;i++){float k=calibration.getFloat(calibrationKeys[i],0);if(std::isfinite(k)&&k>=0&&k<=1000)distanceK[i]=k;}
}
String makeCameraStatus(){
 sensor_t *s=esp_camera_sensor_get();String j="{";
 j+="\"framesize\":"+String((int)s->status.framesize);
 j+=",\"quality\":"+String((int)s->status.quality);
 j+=",\"brightness\":"+String((int)s->status.brightness);
 j+=",\"contrast\":"+String((int)s->status.contrast);
 j+=",\"saturation\":"+String((int)s->status.saturation);
 j+=",\"special_effect\":"+String((int)s->status.special_effect);
 j+=",\"wb_mode\":"+String((int)s->status.wb_mode);
 j+=",\"awb\":"+String((int)s->status.awb);
 j+=",\"awb_gain\":"+String((int)s->status.awb_gain);
 j+=",\"aec\":"+String((int)s->status.aec);
 j+=",\"aec2\":"+String((int)s->status.aec2);
 j+=",\"ae_level\":"+String((int)s->status.ae_level);
 j+=",\"aec_value\":"+String((int)s->status.aec_value);
 j+=",\"agc\":"+String((int)s->status.agc);
 j+=",\"agc_gain\":"+String((int)s->status.agc_gain);
 j+=",\"gainceiling\":"+String((int)s->status.gainceiling);
 j+=",\"bpc\":"+String((int)s->status.bpc);
 j+=",\"wpc\":"+String((int)s->status.wpc);
 j+=",\"raw_gma\":"+String((int)s->status.raw_gma);
 j+=",\"lenc\":"+String((int)s->status.lenc);
 j+=",\"vflip\":"+String((int)s->status.vflip);
 j+=",\"hmirror\":"+String((int)s->status.hmirror);
 j+=",\"dcw\":"+String((int)s->status.dcw);
 j+=",\"colorbar\":"+String((int)s->status.colorbar);
 j+=",\"detect\":"+String((bool)detectEnabled)+",\"input_bgr\":"+String(inputBGR)+",\"view_mode\":"+String(viewMode)+",\"view_cx\":"+String(viewCx)+",\"view_cy\":"+String(viewCy)+",\"threshold\":"+String((int)(aiThreshold*100+0.5f));
 j+=",\"sensor_pid\":"+String(s->id.PID)+",\"firmware\":\"A2 YOLO FAST 15\"}";return j;
}
bool cameraRange(const String &key,int val){
 if(key=="framesize")return val==0||(val>=3&&val<=10);
 if(key=="quality")return val>=10&&val<=63;
 if(key=="brightness"||key=="contrast"||key=="saturation"||key=="ae_level")return val>=-2&&val<=2;
 if(key=="agc_gain")return val>=0&&val<=30;
 if(key=="aec_value")return val>=0&&val<=1200;
 if(key=="special_effect"||key=="gainceiling")return val>=0&&val<=6;
 if(key=="wb_mode")return val>=0&&val<=4;
 if(key=="view_mode")return val>=0&&val<=3;
 if(key=="view_cx"||key=="view_cy")return val>=0&&val<=1000;
 if(key=="threshold")return val>=50&&val<=99;
 return val==0||val==1;
}
void cameraControl(){
 String key=web.arg("var");if(key.startsWith("face_")||key=="color_detect"){web.send(410,"text/plain","Removed in FAST firmware");return;}String value=web.arg("val");char *end=nullptr;long n=strtol(value.c_str(),&end,10);
 if(!value.length()||value.length()>6||*end||!cameraRange(key,n)){web.send(400,"text/plain","Invalid setting/value");return;}
 sendJSON("{\"N\":100}");owner=0;
 if(key=="threshold"){pendingThreshold.store((int)n);web.send(202,"text/plain","Queued for next frame; check Applied threshold");return;}
 if(key=="framesize"){
  if(resolutionBusy.exchange(true)){web.send(409,"text/plain","A resolution change is already pending");return;}
  xSemaphoreTake(stateMutex,portMAX_DELAY);resolutionId++;requestedResolution=n;resolutionState="queued";resolutionMessage="Waiting for current inference to finish";uint32_t id=resolutionId;xSemaphoreGive(stateMutex);
  pendingResolution=n;web.send(202,"application/json",String("{\"id\":")+String(id)+"}");return;
 }
 if(resolutionBusy){web.send(503,"text/plain","Resolution change pending; retry shortly");return;}
 if(xSemaphoreTake(frameMutex,pdMS_TO_TICKS(20))!=pdTRUE){web.send(503,"text/plain","Vision busy; retry");return;}
 if(xSemaphoreTake(cameraMutex,pdMS_TO_TICKS(20))!=pdTRUE){xSemaphoreGive(frameMutex);web.send(503,"text/plain","Camera busy; retry shortly");return;}
 sensor_t *s=esp_camera_sensor_get();int val=n,res=0;
 if(key=="quality")res=s->set_quality(s,val);
 else if(key=="contrast")res=s->set_contrast(s,val);
 else if(key=="brightness")res=s->set_brightness(s,val);
 else if(key=="saturation")res=s->set_saturation(s,val);
 else if(key=="gainceiling")res=s->set_gainceiling(s,(gainceiling_t)val);
 else if(key=="colorbar")res=s->set_colorbar(s,val);
 else if(key=="awb")res=s->set_whitebal(s,val);
 else if(key=="agc")res=s->set_gain_ctrl(s,val);
 else if(key=="aec")res=s->set_exposure_ctrl(s,val);
 else if(key=="hmirror")res=s->set_hmirror(s,val);
 else if(key=="vflip")res=s->set_vflip(s,val);
 else if(key=="awb_gain")res=s->set_awb_gain(s,val);
 else if(key=="agc_gain")res=s->set_agc_gain(s,val);
 else if(key=="aec_value")res=s->set_aec_value(s,val);
 else if(key=="aec2")res=s->set_aec2(s,val);
 else if(key=="dcw")res=s->set_dcw(s,val);
 else if(key=="bpc")res=s->set_bpc(s,val);
 else if(key=="wpc")res=s->set_wpc(s,val);
 else if(key=="raw_gma")res=s->set_raw_gma(s,val);
 else if(key=="lenc")res=s->set_lenc(s,val);
 else if(key=="special_effect")res=s->set_special_effect(s,val);
 else if(key=="wb_mode")res=s->set_wb_mode(s,val);
 else if(key=="ae_level")res=s->set_ae_level(s,val);

 else if(key=="detect")detectEnabled=val;
 else if(key=="input_bgr")inputBGR=val;
 else if(key=="view_mode")viewMode=val;
 else if(key=="view_cx")viewCx=val;
 else if(key=="view_cy")viewCy=val;
 else if(key=="threshold")aiThreshold=val/100.0f;
 else res=-1;
 if(!res)geometryEpoch++;
 xSemaphoreTake(stateMutex,portMAX_DELAY);cameraStatus=makeCameraStatus();xSemaphoreGive(stateMutex);
 xSemaphoreGive(cameraMutex);
 xSemaphoreGive(frameMutex);
 web.send(res?400:200,"text/plain",res?"Unsupported setting / sensor rejected value":"Applied; vehicle stopped");
}

void printSerialResult(const String &json){
#if A2_SERIAL_MODE == 1
 int best=-1;for(int i=0;i<objectCount;i++)if(detections[i].id==1&&(best<0||detections[i].confidence>detections[best].confidence))best=i;
 // One labelled numeric row per completed inference, also when no STOP is found.
 bool found=frameValid&&best>=0;
 Serial.printf("Valid:%d\tSTOP:%d\tConfidence_pct:%.1f\tRaw_pct:%.1f\tCellWidth_px:%d\tCellHeight_px:%d\tDistance_cm:%d\tInference_ms:%lu\tAI_error:%d\n",
  frameValid,found,found?detections[best].confidence*100:0,
  frameValid&&rawDiagnostic.available?rawDiagnostic.score*100:0,
  found?detections[best].box.x1-detections[best].box.x0+1:0,
  found?detections[best].box.y1-detections[best].box.y0+1:0,
  -1,(unsigned long)totalInferenceMs,aiError);
#elif A2_SERIAL_MODE == 2
 Serial.println(json);
#else
 Serial.printf("\nFrame %u | STOP %d | AI error %d\nCapture %lu ms | Decode %lu ms | DSP %lu ms | NN %lu ms | Total %lu ms | Arena %s\n",sequence,stopCount,aiError,(unsigned long)captureMs,(unsigned long)decodeMs,(unsigned long)dspMs,(unsigned long)nnMs,(unsigned long)processMs,eiArenaInternal()?"internal":"PSRAM");
 for(int i=0;i<objectCount;i++){Detection &d=detections[i];Serial.printf("STOP %.1f%% x=%d y=%d w=%d h=%d distance=%d cm\n",d.confidence*100,d.box.x0,d.box.y0,d.box.x1-d.box.x0+1,d.box.y1-d.box.y0+1,d.distance);}

#endif
}

// Snapshot storage is separate from preview and updated only on explicit request.
std::atomic<bool> snapshotPending{false};
uint32_t snapshotId=0;
uint8_t *snapshotJpeg=nullptr,*snapshotBmp=nullptr;
size_t snapshotJpegLen=0;
String snapshotMeta="{}",snapshotError="No snapshot yet";
void bmp32(uint8_t*p,uint32_t v){for(int i=0;i<4;i++)p[i]=(v>>(8*i))&255;}
void saveRequestedSnapshot(const String &result){
 if(!snapshotPending)return;
 uint8_t *jpg=nullptr,*bmp=nullptr;size_t n=0;String failure="";int reference=-1;
 if(!cameraOK||!frame||!rgbOK)failure="Camera/decode failed; retry";
 else{
  n=frame->len;jpg=(uint8_t*)ps_malloc(n);bmp=(uint8_t*)ps_malloc(54+MODEL_RGB_BYTES);
  if(!jpg||!bmp){free(jpg);free(bmp);jpg=bmp=nullptr;failure="Snapshot allocation failed";}
  else{
   memcpy(jpg,frame->buf,n);memset(bmp,0,54);bmp[0]='B';bmp[1]='M';bmp32(bmp+2,54+MODEL_RGB_BYTES);bmp32(bmp+10,54);bmp32(bmp+14,40);bmp32(bmp+18,MODEL_SIDE);bmp32(bmp+22,MODEL_SIDE);bmp[26]=1;bmp[28]=24;
   for(int y=0;y<MODEL_SIDE;y++)for(int x=0;x<MODEL_SIDE;x++){uint32_t c=packedPixel(rgb+3*(y*MODEL_SIDE+x));int k=54+3*((MODEL_SIDE-1-y)*MODEL_SIDE+x);bmp[k]=c&255;bmp[k+1]=(c>>8)&255;bmp[k+2]=(c>>16)&255;}
   reference=checkSnapshotInput(frame,rgb,analysisW,analysisH,aiView);
  }
 }
 xSemaphoreTake(stateMutex,portMAX_DELAY);
 free(snapshotJpeg);free(snapshotBmp);snapshotJpeg=jpg;snapshotBmp=bmp;snapshotJpegLen=jpg?n:0;snapshotId++;snapshotError=failure;
 snapshotMeta=result;if(snapshotMeta.endsWith("}"))snapshotMeta.remove(snapshotMeta.length()-1);
 snapshotMeta+=",\"snapshot_id\":"+String(snapshotId)+",\"input_reference_match\":"+String(reference)+",\"input_bgr\":"+String(inputBGR)+",\"view_mode\":"+String(viewMode)+"}";
 snapshotPending=false;xSemaphoreGive(stateMutex);
}
void requestSnapshot(){
 if(resolutionBusy){web.send(409,"text/plain","Wait for the resolution change to finish before capture");return;}
 sendJSON("{\"N\":100}");owner=0;
 xSemaphoreTake(stateMutex,portMAX_DELAY);snapshotPending=true;uint32_t target=snapshotId+1;xSemaphoreGive(stateMutex);
 web.send(202,"application/json","{\"id\":"+String(target)+"}");
}
void snapshotState(){
 xSemaphoreTake(stateMutex,portMAX_DELAY);String s="{\"id\":"+String(snapshotId)+",\"pending\":"+String((bool)snapshotPending)+",\"ready\":"+String(snapshotJpeg&&snapshotBmp)+",\"error\":\""+snapshotError+"\"}";xSemaphoreGive(stateMutex);
 web.sendHeader("Cache-Control","no-store");web.send(200,"application/json",s);
}
void sendSnapshot(int kind){
 uint8_t *copy=nullptr;size_t n=0;String meta;uint32_t id=0;bool mismatch=false;
 xSemaphoreTake(stateMutex,portMAX_DELAY);id=snapshotId;
 mismatch=web.hasArg("id")&&web.arg("id")!=String(id);
 if(!mismatch&&snapshotJpeg){
  meta=snapshotMeta;
  if(kind<2){n=kind==0?snapshotJpegLen:(54+MODEL_RGB_BYTES);copy=(uint8_t*)ps_malloc(n);if(copy)memcpy(copy,kind==0?snapshotJpeg:snapshotBmp,n);}
 }
 xSemaphoreGive(stateMutex);
 if(mismatch){web.send(409,"text/plain","Snapshot changed; request a new capture");return;}
 if(meta==""){if(!web.hasArg("id"))snapshotPending=true;web.send(503,"text/plain","Waiting for capture; retry shortly or use the Capture button");return;}
 if(kind<2&&!copy){web.send(503,"text/plain","Snapshot copy allocation failed");return;}
 web.sendHeader("Cache-Control","no-store");web.sendHeader("X-Snapshot-Id",String(id));
 if(kind==2){if(web.arg("download")=="1")web.sendHeader("Content-Disposition",String("attachment; filename=\"esp32_")+String(id)+".json\"");web.send(200,"application/json",meta);return;}
 if(web.arg("download")=="1")web.sendHeader("Content-Disposition",String("attachment; filename=\"esp32_")+String(id)+(kind==0?".jpg\"":"_input.bmp\""));
 web.setContentLength(n);web.send(200,kind==0?"image/jpeg":"image/bmp","");web.client().write(copy,n);free(copy);
}
String redResults(){
 xSemaphoreTake(stateMutex,portMAX_DELAY);RedStatus r=redStatus;xSemaphoreGive(stateMutex);
 bool enabled=colorEnabled.load();bool fresh=!resolutionBusy&&r.valid&&(millis()-r.captured)<1200;
 String j="{\"enabled\":"+String(enabled)+",\"valid\":"+String(fresh&&enabled)+",\"seen\":"+String(enabled&&fresh&&r.seen);
 j+=",\"pixels\":"+String(r.region.pixels)+",\"min_pixels\":"+String(redMinPixels.load())+",\"age_ms\":"+String(millis()-r.captured)+",\"processing_ms\":"+String(r.ms);
 j+=",\"x\":"+String(r.region.x)+",\"y\":"+String(r.region.y)+",\"w\":"+String(r.region.w)+",\"h\":"+String(r.region.h)+",\"image_w\":"+String(r.region.imageW)+",\"image_h\":"+String(r.region.imageH)+"}";return j;
}
void redTask(void*){
 for(;;){
  RedStatus next;uint32_t start=millis();
  if(colorEnabled&&!resolutionBusy){
   xSemaphoreTake(cameraMutex,portMAX_DELAY);
   if(resolutionBusy){xSemaphoreGive(cameraMutex);vTaskDelay(pdMS_TO_TICKS(20));continue;}
   camera_fb_t *rf=esp_camera_fb_get();next.captured=millis();
   xSemaphoreTake(decoderMutex,portMAX_DELAY);next.valid=decodeRed(rf,redCells,redQueue,next.region);xSemaphoreGive(decoderMutex);
   if(rf)esp_camera_fb_return(rf);xSemaphoreGive(cameraMutex);
   next.seen=next.valid&&next.region.pixels>=redMinPixels.load();
  }else next.captured=millis();
  next.ms=millis()-start;xSemaphoreTake(stateMutex,portMAX_DELAY);redStatus=next;xSemaphoreGive(stateMutex);
  vTaskDelay(pdMS_TO_TICKS(150));
 }
}
void resolutionProgress(const char *state,const char *message){
 xSemaphoreTake(stateMutex,portMAX_DELAY);resolutionState=state;resolutionMessage=message;xSemaphoreGive(stateMutex);
}
bool checkCameraSize(int id){
 int expectedW,expectedH;if(!resolutionSize(id,expectedW,expectedH))return false;
 for(int i=0;i<4;i++){
  camera_fb_t *test=esp_camera_fb_get();int w=0,h=0;
  bool ok=test&&test->format==PIXFORMAT_JPEG&&jpegSize(test->buf,test->len,w,h)&&w==expectedW&&h==expectedH;
  if(test)esp_camera_fb_return(test);
  // Discard the first two frames after the register change.
  if(i>=2&&ok){xSemaphoreTake(stateMutex,portMAX_DELAY);verifiedWidth=w;verifiedHeight=h;xSemaphoreGive(stateMutex);return true;}
  vTaskDelay(pdMS_TO_TICKS(20));
 }
 return false;
}
void applyPendingResolution(){
 int target=pendingResolution.exchange(-1);if(target<0)return;
 resolutionProgress("applying","Pausing red analysis and switching camera resolution");
 if(xSemaphoreTake(cameraMutex,pdMS_TO_TICKS(3000))!=pdTRUE){resolutionProgress("failed","Camera busy; previous resolution retained. Retry or check serial output.");resolutionBusy=false;return;}
 sensor_t *sensor=esp_camera_sensor_get();int old=(int)sensor->status.framesize;
 releaseFrame();inputReady=false;objectCount=0;stopCount=0;frameValid=false;cameraOK=false;rgbOK=false;rawDiagnostic={};geometryEpoch++;
 xQueueReset(visionQueue);
 xSemaphoreTake(stateMutex,portMAX_DELAY);redStatus={};free(completedJpeg);completedJpeg=nullptr;completedLen=0;cachedResults="{\"seq\":0,\"valid\":0,\"objects\":[]}";xSemaphoreGive(stateMutex);
 bool success=sensor->set_framesize(sensor,(framesize_t)target)==0;
 if(success){resolutionProgress("verifying","Waiting for a JPEG with the requested dimensions");success=checkCameraSize(target);}
 if(success){loadCalibration(target);resolutionProgress("applied","Resolution verified from a new JPEG; analysis resumes automatically");}
 else {
  bool restored=sensor->set_framesize(sensor,(framesize_t)old)==0&&checkCameraSize(old);
  resolutionProgress("failed",restored?"Requested resolution failed; previous resolution restored":"Camera did not produce a valid frame. Check serial output and power-cycle if needed");
 }
 xSemaphoreTake(stateMutex,portMAX_DELAY);cameraStatus=makeCameraStatus();xSemaphoreGive(stateMutex);
 xSemaphoreGive(cameraMutex);resolutionBusy=false;
 Serial.printf("Resolution request %d: %s; JPEG %dx%d\n",target,success?"verified":"failed",verifiedWidth,verifiedHeight);
}
String resolutionStatus(){
 xSemaphoreTake(stateMutex,portMAX_DELAY);
 String j="{\"id\":"+String(resolutionId)+",\"requested\":"+String(requestedResolution)+",\"state\":\""+resolutionState+"\",\"message\":\""+resolutionMessage+"\",\"width\":"+String(verifiedWidth)+",\"height\":"+String(verifiedHeight)+"}";
 xSemaphoreGive(stateMutex);return j;
}
void visionTask(void*){
 uint32_t previousStart=0;
 for(;;){
  uint32_t cycleStart=millis();cycleMs=previousStart?cycleStart-previousStart:0;previousStart=cycleStart;
  if(xSemaphoreTake(frameMutex,portMAX_DELAY)==pdTRUE){
   applyPendingResolution();
   int nextThreshold=pendingThreshold.exchange(-1);if(nextThreshold>=50&&nextThreshold<=99)aiThreshold=nextThreshold/100.0f;
   bool captureThisFrame=snapshotPending.load();
   acquire();String result=results();
   result.remove(result.length()-1);result+=",\"detect_enabled\":"+String((bool)detectEnabled)+",\"color_enabled\":"+String((bool)colorEnabled)+"}";
   uint8_t *next=nullptr;size_t n=0;if(cameraOK&&previewEnabled){n=frame->len;next=(uint8_t*)ps_malloc(n);if(next)memcpy(next,frame->buf,n);}
   xSemaphoreTake(stateMutex,portMAX_DELAY);cachedResults=result;free(completedJpeg);completedJpeg=next;completedLen=next?n:0;cameraStatus=makeCameraStatus();xSemaphoreGive(stateMutex);
   if(captureThisFrame)saveRequestedSnapshot(result);
   releaseFrame();
   xSemaphoreGive(frameMutex);printSerialResult(result);
  }
  vTaskDelay(pdMS_TO_TICKS(FRAME_INTERVAL_MS));
 }
}
bool strictInt(const String &s,int lo,int hi,int &v){
 if(!s.length()||s.length()>5)return false;
 for(size_t i=0;i<s.length();i++)if(s[i]<'0'||s[i]>'9')return false;
 v=s.toInt();return v>=lo&&v<=hi;
}
void webCommand(){
 String action=web.arg("action");String j;
 int value;
 if(action=="preview"){previewEnabled=web.arg("value")=="1";web.send(200,"text/plain","Preview updated");return;}
 if(action=="red_min"){if(!strictInt(web.arg("value"),2,2000,value)){web.send(400,"text/plain","Red minimum must be 2-2000 pixels");return;}redMinPixels=value;web.send(200,"text/plain","Red minimum updated");return;}
 if(action=="stop"){j="{\"N\":100}";owner=0;}
 else if(action=="ping"){if(owner==1)sendJSON("{\"N\":103}");web.send(200,"text/plain","ok");return;}
 else if(action=="move"){
  int speed;if(!strictInt(web.arg("dir"),1,9,value)||!strictInt(web.arg("speed"),0,180,speed)){web.send(400,"text/plain","Bad direction/speed");return;}
  j="{\"N\":102,\"D1\":"+String(value)+",\"D2\":"+String(speed)+"}";owner=value==9?0:1;
 }else if(action=="mode"){
  if(!strictInt(web.arg("value"),0,4,value)){web.send(400,"text/plain","Bad mode");return;}
  if(value==4&&(!A2_ENABLE_AI||!detectEnabled)){web.send(409,"text/plain","Import model and enable AI first");return;}
  j="{\"N\":101,\"D1\":"+String(value)+"}";owner=value==0?0:1;
 }else if(action=="speed"){
  if(!strictInt(web.arg("value"),0,180,value)){web.send(400,"text/plain","Bad speed");return;}
  j="{\"N\":104,\"D1\":"+String(value)+"}";
 }else if(action=="servo"){
  if(!strictInt(web.arg("value"),0,180,value)){web.send(400,"text/plain","Bad servo angle");return;}
  owner=0;j="{\"N\":5,\"D1\":1,\"D2\":"+String(value)+"}";
 }else if(action=="led"){
  int r,g,b;if(!strictInt(web.arg("r"),0,255,r)||!strictInt(web.arg("g"),0,255,g)||!strictInt(web.arg("b"),0,255,b)){web.send(400,"text/plain","Bad RGB");return;}
  j="{\"N\":8,\"D1\":0,\"D2\":"+String(r)+",\"D3\":"+String(g)+",\"D4\":"+String(b)+"}";
 }else if(action=="guard"){
  if(!strictInt(web.arg("value"),0,1,value)){web.send(400,"text/plain","Bad guard flag");return;}
  if(value&&(!A2_ENABLE_AI||!detectEnabled)){web.send(409,"text/plain","No AI model");return;}
  j="{\"N\":201,\"D1\":"+String(value)+"}";owner=0;
 }else if(action=="reset_stop"){j="{\"N\":202}";owner=0;}
 else if(action=="detect"||action=="color"){
  if(!strictInt(web.arg("value"),0,1,value)){web.send(400,"text/plain","Bad flag");return;}
  if(action=="detect"&&value&&!A2_ENABLE_AI){web.send(409,"text/plain","Firmware has no model");return;}
  // Changing either analysis setting stops the car first.
  sendJSON("{\"N\":100}");owner=0;
  if(action=="detect")detectEnabled=value;else colorEnabled=value;
  web.send(200,"text/plain","Changed; vehicle stopped");return;
 }else{web.send(400,"text/plain","Unknown action");return;}
 sendJSON(j);web.send(200,"application/json",j);
}
void calibrateDistance(){
 if(web.arg("clear")!="1"){web.send(409,"text/plain","FOMO provides centroid regions, not object dimensions. Size calibration is unavailable.");return;}
 int id,width,cm,referenceW,resolution,epoch;int slot;
 if(!strictInt(web.arg("id"),1,1,id)||(slot=calibrationSlot(id))<0){web.send(400,"text/plain","Invalid object type");return;}
 bool clear=web.arg("clear")=="1";
 if(!clear && (!strictInt(web.arg("width"),6,ANALYSIS_MAX_W-2,width)||!strictInt(web.arg("cm"),5,1000,cm)||!strictInt(web.arg("image_w"),96,400,referenceW)||!strictInt(web.arg("framesize"),0,10,resolution)||!strictInt(web.arg("epoch"),0,65535,epoch))){web.send(400,"text/plain","Need sampled width and known distance 5-1000 cm");return;}
 sendJSON("{\"N\":100}");owner=0;
 if(xSemaphoreTake(frameMutex,pdMS_TO_TICKS(20))!=pdTRUE){web.send(503,"text/plain","Vision busy; press Save again");return;}
 if(!clear && (resolution!=(int)esp_camera_sensor_get()->status.framesize || epoch!=geometryEpoch || referenceW!=analysisW)){xSemaphoreGive(frameMutex);web.send(409,"text/plain","Camera settings changed. Sample again.");return;}
 float k=clear?0.0f:(float)width*cm/referenceW;
 bool saved=calibrationReady;
 if(saved){if(calibration.getInt("res",-1)!=calibrationResolution){for(int i=0;i<5;i++)saved=(calibration.putFloat(calibrationKeys[i],0)==sizeof(float))&&saved;}saved=(calibration.putInt("res",calibrationResolution)==sizeof(int))&&saved;saved=(calibration.putFloat(calibrationKeys[slot],k)==sizeof(float))&&saved;}
 if(saved)distanceK[slot]=k;
 xSemaphoreGive(frameMutex);
 if(!saved){web.send(500,"text/plain","Calibration could not be stored");return;}
 web.send(200,"text/plain",String(clear?"Calibration cleared. ":"Calibration saved. ")+"K="+String(k,2)+" cm (normalized width); vehicle stopped");
}
void bridge(){
 while(Serial2.available()){
  char c=Serial2.read();if(c=='{')unoRx="";
  if(unoRx.length()<250)unoRx+=c;else unoRx="";
  if(c=='}'){
   if(unoRx.startsWith("{\"N\":210,")){unoStatus=unoRx;lastUno=millis();}
   else lastReply=unoRx;

   unoRx="";
  }
 }
}
void setup(){
 Serial.begin(115200);Serial2.begin(9600,SERIAL_8N1,UART_RX,UART_TX);sendJSON("{\"N\":100}");
 frameMutex=xSemaphoreCreateMutex();stateMutex=xSemaphoreCreateMutex();cameraMutex=xSemaphoreCreateMutex();decoderMutex=xSemaphoreCreateMutex();visionQueue=xQueueCreate(1,sizeof(VisionPayload));
 if(!frameMutex||!stateMutex||!visionQueue||!cameraMutex||!decoderMutex){Serial.println("ERROR synchronization allocation");while(true)delay(1000);}
#if A2_ENABLE_AI
 if(strcmp(ei_classifier_inferencing_categories[0],"3")){
  Serial.println("ERROR: expected model target class 3");while(true)delay(1000);
 }
#endif
 if(!psramFound()){Serial.println("ERROR: enable PSRAM");while(true)delay(1000);}
 prepareEiArena();
 redCells=(uint8_t*)ps_malloc(10000);redQueue=(uint16_t*)ps_malloc(20000);
 rgb=(uint8_t*)ps_malloc(MODEL_RGB_BYTES);
 if(!rgb||!redCells||!redQueue||!cameraInit()){Serial.println("ERROR: camera/memory");while(true)delay(1000);}
 calibrationReady=calibration.begin("a2-cam-v2",false);
 loadCalibration(5);
 detectEnabled=A2_ENABLE_AI;
 WiFi.mode(WIFI_AP);WiFi.softAP(AP_SSID,AP_PASSWORD,AP_CHANNEL);
 web.on("/",HTTP_GET,[]{web.send_P(200,"text/html",PAGE);});
 web.on("/resolution-status",HTTP_GET,[]{web.sendHeader("Cache-Control","no-store");web.send(200,"application/json",resolutionStatus());});
 web.on("/red",HTTP_GET,[]{web.sendHeader("Cache-Control","no-store");web.send(200,"application/json",redResults());});
 web.on("/results",HTTP_GET,[]{
  xSemaphoreTake(stateMutex,portMAX_DELAY);String s=cachedResults;xSemaphoreGive(stateMutex);
  if(s.endsWith("}"))s.remove(s.length()-1);
  s+=",\"uno\":"+unoStatus+",\"uno_age_ms\":"+String(millis()-lastUno)+",\"detect_enabled\":"+String((bool)detectEnabled)+",\"color_enabled\":"+String((bool)colorEnabled)+"}";
  web.sendHeader("Cache-Control","no-store");web.send(200,"application/json",s);
 });
 web.on("/frame",HTTP_GET,[]{
  uint8_t *copy=nullptr;size_t n=0;String meta;
  xSemaphoreTake(stateMutex,portMAX_DELAY);if(completedJpeg){n=completedLen;copy=(uint8_t*)ps_malloc(n);if(copy){memcpy(copy,completedJpeg,n);meta=cachedResults;}}xSemaphoreGive(stateMutex);
  if(!copy){web.send(503,"text/plain","Waiting for a completed analysis frame");return;}
  if(meta.endsWith("}"))meta.remove(meta.length()-1);meta+=",\"uno\":"+unoStatus+",\"uno_age_ms\":"+String(millis()-lastUno)+"}";
  web.sendHeader("Cache-Control","no-store");web.sendHeader("X-Analysis",meta);web.setContentLength(n);web.send(200,"image/jpeg","");web.client().write(copy,n);free(copy);
 });
 web.on("/snapshot",HTTP_POST,requestSnapshot);
 web.on("/snapshot",HTTP_GET,snapshotState);
 web.on("/capture",HTTP_GET,[]{sendSnapshot(0);});
 web.on("/model-input",HTTP_GET,[]{sendSnapshot(1);});
 web.on("/snapshot-meta",HTTP_GET,[]{sendSnapshot(2);});
 web.on("/status",HTTP_GET,[]{xSemaphoreTake(stateMutex,portMAX_DELAY);String s=cameraStatus;xSemaphoreGive(stateMutex);web.sendHeader("Cache-Control","no-store");web.send(200,"application/json",s);});
 web.on("/control",HTTP_GET,cameraControl);web.on("/control",HTTP_POST,cameraControl);
 web.on("/cmd",HTTP_POST,webCommand);
 web.on("/calibrate",HTTP_POST,calibrateDistance);
 web.begin();
 if(xTaskCreatePinnedToCore(redTask,"red",8192,nullptr,1,nullptr,0)!=pdPASS){Serial.println("ERROR red task");while(true)delay(1000);}
 if(xTaskCreatePinnedToCore(visionTask,"vision",16384,nullptr,1,nullptr,1)!=pdPASS){Serial.println("ERROR vision task");while(true)delay(1000);}
 Serial.println("FAST dashboard http://192.168.4.1 ; preview OFF by default");
}
void loop(){
 web.handleClient();bridge();
 VisionPayload v;
 if(xQueueReceive(visionQueue,&v,0)==pdTRUE){
  char s[160];snprintf(s,sizeof(s),"{\"N\":200,\"S\":%u,\"A\":%d,\"V\":%d,\"P\":%d,\"R\":%d,\"X\":%d,\"Y\":%d,\"W\":%d,\"H\":%d,\"O\":%d}",
   v.seq,v.ai,(v.valid&&millis()-v.captured<=2000),v.confidence,v.distance,v.cx,v.cy,v.w,v.h,stopIndicatorReady(v.observed,v.completed,millis(),detectEnabled,resolutionBusy));
  sendJSON(s);
 }
 static uint32_t lastRedSend=0;
 if(millis()-lastRedSend>=200){
  lastRedSend=millis();xSemaphoreTake(stateMutex,portMAX_DELAY);RedStatus r=redStatus;xSemaphoreGive(stateMutex);
  bool ok=!resolutionBusy&&colorEnabled&&r.valid&&millis()-r.captured<1200;
  sendJSON(String("{\"N\":203,\"R\":")+String(ok&&r.seen)+"}");
 }
 delay(1);
}
