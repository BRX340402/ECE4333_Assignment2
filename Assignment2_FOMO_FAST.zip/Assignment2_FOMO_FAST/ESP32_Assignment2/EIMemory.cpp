#include <Arduino.h>
#include <esp_heap_caps.h>
#include <string.h>
#include "Config.h"
#include "edge-impulse-sdk/porting/ei_classifier_porting.h"
// v6 FOMO EON arena + ei_aligned_calloc's 17-byte header. Single vision task only.
static const size_t arenaBytes=395616+17;
static void *arenaPool=nullptr;static bool arenaBusy=false;
void prepareEiArena(){
#if A2_INTERNAL_ARENA
 // Leave 80 KiB for Wi-Fi, camera DMA, task stacks and HTTP. If not possible,
 // use PSRAM rather than starving the rest of the firmware.
 size_t freeBytes=heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
 if(freeBytes>=arenaBytes+80*1024 && heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)>=arenaBytes)
  arenaPool=heap_caps_malloc(arenaBytes,MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
#endif
 Serial.printf("Model arena: %s\n",arenaPool?"reserved internal RAM":"PSRAM fallback");
}
bool eiArenaInternal(){return arenaPool!=nullptr;}
void *ei_malloc(size_t size){
 if(size==arenaBytes&&arenaPool&&!arenaBusy){arenaBusy=true;return arenaPool;}
 // Tiny hot bookkeeping uses internal RAM only while a reserve remains.
 void*p=nullptr;
 if(size<4096&&heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)>48*1024+size)
  p=heap_caps_malloc(size,MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
 if(!p)p=heap_caps_malloc(size,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
 if(!p)Serial.printf("EI allocation failed: %u bytes\n",(unsigned)size);
 return p;
}
void *ei_calloc(size_t count,size_t size){if(size&&count>SIZE_MAX/size)return nullptr;size_t bytes=count*size;void*p=ei_malloc(bytes);if(p)memset(p,0,bytes);return p;}
void ei_free(void *ptr){if(ptr&&ptr==arenaPool){arenaBusy=false;return;}heap_caps_free(ptr);}
