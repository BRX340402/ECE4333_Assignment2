# FAST18 — FOMO v1.0.6

此版接入上传的 deployment 6：160×160 RGB、int8 FOMO、20×20×2 输出（背景 + 类别 `3`）。`3` 继续映射为 STOP。实际 EON arena 为 395,616 字节，另有 17 字节对齐开销；需要 PSRAM。不能仅凭 FOMO 名称承诺板上速度。

## 安装

1. Arduino IDE → Sketch → Include Library → Add .ZIP Library，安装本包 `Arduino_Libraries/A2_StopSign_FOMO_104.zip`。若 libraries 中已有同名旧 FOMO 库，先将它移出 libraries 目录再安装。这个库是 v1.0.6，不是之前的旧 FOMO 模型。
2. 上传 `ESP32_Assignment2/ESP32_Assignment2.ino`：ESP32 Dev Module、ESP32 core 1.0.4、Huge APP、4MB Flash、PSRAM Enabled、240MHz。
3. 若 UNO 已上传 FAST17，无需再次更新；若仍为 FAST16 或更早版本，请上传包内 `UNO_Assignment2/UNO_Assignment2.ino`，保留 10 秒 STOP 灯保持规则。
4. 刷新浏览器，确认 FOMO FAST 18 / Model v6 / 160×160。压缩包/主目录沿用原工程名称，但本版执行 FOMO，不再执行 YOLO。

## 功能

- 保留独立红色检测及闪烁、STOP 长亮优先、识别完成时间计时、UNO 10 秒断更超时。
- 保留默认 CIF、异步分辨率切换/失败回退、英文 UI、阈值控制、原图 JPEG + 同帧 160×160 BMP + JSON 截图。
- 原始诊断改为 400 个 FOMO 网格单元中 STOP 得分最高的单元，位于内部 50% 过滤和单元合并之前。黄色区域不代表已识别，不触发灯光或电机。
- FOMO 返回的区域用于定位目标中心，不能作为停车牌实际边界。距离输出为 unavailable，size_valid=0，尺寸标定保存/采样禁用，服务端也拒绝保存。保留清除入口；旧 YOLO 标定独立保存，不用于 FOMO。直接用 FOMO 网格宽度计算厘米数会产生错误距离。
- 电机逻辑未改：仍要求采集后 2 秒内的数据。原有保护在高置信度 STOP 且距离未知时仍可能停车；不要把未知距离理解为目标很远。

## 编译结果

ESP32 最终编译通过：Flash 1,001,122 / 3,145,728 字节（31%）；静态 RAM 50,608 字节（15%），不包含运行时 PSRAM 分配。

## 验证与实测

ESP32 编译记录和测试范围见 build_validation/FAST18_validation.txt。模型原始元数据、量化参数、权重保持；仅保留旧 ESP32 核心兼容修复、优化、协作调度和原始分数观察钩子。

没有实体板，无法保证速度或识别准确率。先关闭 Preview，固定 CIF，测试 20/30/40/50 cm。记录 NN / Processing / Previous cycle、ai_error、STOP 置信度、UNO red LED。再开启 Preview 比较。新库 arena 约 386 KiB，比前版 YOLO 的约 251 KiB 更大；模型工作内存大小与推理时间不是同一个指标。

UNO 本版与 FAST17 完全相同。本环境没有 AVR 工具链，未做 UNO 整体编译。
