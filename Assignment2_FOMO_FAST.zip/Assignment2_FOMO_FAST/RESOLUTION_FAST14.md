# FAST 14: asynchronous resolution switching

## Update
From FAST13, upload ONLY ESP32_Assignment2/ESP32_Assignment2.ino. UNO and the model library are unchanged.
Use ESP32 Dev Module, core 1.0.4, Huge APP, PSRAM Enabled, 4MB flash, CPU 240MHz.
Refresh the dashboard and confirm YOLO FAST 14.

## Operation
Select a resolution once and wait for the status below it. The request is queued and the HTTP handler responds immediately. The current inference finishes, red capture pauses, and the camera is switched under its ownership lock. Preview fetching pauses in the browser.
Two transition frames are discarded. Subsequent JPEG SOF dimensions are checked against the requested resolution. Success is reported only when the encoded image has the requested dimensions. A rejected or unverifiable change attempts to restore and verify the previous resolution; a failed recovery is explicitly reported.
AI/red enable settings and preview selection are retained; analysis resumes automatically. A change stops the car as in prior firmware. New requests cannot replace an in-progress resolution request.
Snapshot downloads already obtained remain valid, but the browser hides the old capture after a resolution change. Wait for confirmation, then Capture new frame. Calibration must be sampled again for the new geometry; a calibration stored at another resolution is not automatically applied.

## Test on the device
1. Start with CIF, AI enabled, red enabled, Preview off.
2. Select VGA once. Wait for 'Resolution applied: 640x480. New JPEG verified.'
3. Repeat with SVGA (800x600), UXGA (1600x1200), and back to CIF.
4. Capture at each selected resolution and inspect the ORIGINAL JPEG dimensions. The AI input remains 96x96.
5. Check red blinking, STOP solid light and calibration after the change.
If disconnected, confirm Wi-Fi connection, reopen http://192.168.4.1/, and inspect http://192.168.4.1/resolution-status. Capture the ESP32 serial output at 115200 including any reset, Guru Meditation or watchdog messages. Software testing cannot establish the physical cause of a device reset without this evidence.

## Other correction
In ESP32 Arduino core 1.0.4, framesize value 0 is QQVGA 160x120, not 96x96. The UI label is corrected. CIF remains the startup default. No 1080p option was added.

## Validation
Native JPEG-header parsing tests passed for valid dimensions, truncated data, bad segment lengths and resolution mapping. Browser mock passed queued/verifying/applied states, failed-change feedback and restored selection, plus red controls, capture, threshold, calibration and mobile layout regressions.
See build_validation/ESP32_FAST14_compile.log for the current ESP32 target compilation result. No physical-board stability verification has been performed. UNO and model-library bytes are unchanged from FAST13.
