# FAST15: uploaded deployment v4

The uploaded ei-bobbywinner-project-1-arduino-1.0.4-impulse-#1.zip contains a newly generated YOLO-Pro int8 model. Its weights and quantization parameters differ from deployment v3, but its input resolution is STILL 96x96 RGB.

Verified in the uploaded files:
- model_metadata.h: deployment version 4, input width 96, height 96, raw sample count 9216, NN input elements 27648.
- Compiled network: input tensor [1,96,96,3], output [1,189,5].
- All 83 tensor-dimension declarations match the prior model.
- Compiled ESP32 tensor arena: 169872 bytes; allocator reservation includes its existing 17-byte alignment header.
- Output quantization: zero point -101, scale 0.005712830927222967 (updated together with the model).
- Target class remains "3"; internal score threshold remains 0.5.

The package therefore does NOT implement a higher-resolution network. Changing camera resolution does not change this input size. To export a higher-resolution model, verify the intended image width/height in the selected Edge Impulse impulse, regenerate features, train the corresponding model and export that trained impulse. The uploaded archive alone cannot establish which Studio step retained the old dimensions.

## Update
1. Close Arduino IDE. Move the old A2_StopSign_YOLO_104 directory OUTSIDE Arduino/libraries.
2. Install Arduino_Libraries/A2_StopSign_YOLO_104.zip FROM THIS PACKAGE. Version 1.0.4 here is the model library version; ESP32 board core also remains 1.0.4, independently.
3. Upload ESP32_Assignment2/ESP32_Assignment2.ino with ESP32 Dev Module / core 1.0.4 / Huge APP / PSRAM Enabled / 4MB / CPU 240MHz.
4. Refresh the webpage and confirm YOLO FAST15 (displayed with a space: YOLO FAST 15), Model v4 / 96x96.
5. If UNO already runs FAST13/14, no UNO update is required. Its files are unchanged.
6. Compare predictions and inference timing on stationary 20/30/40/50 cm scenes before evaluating moving-car behavior. Accuracy and runtime have not been measured on hardware for this new model.

Preserved: FAST14 background resolution switching and JPEG-size verification, independent red detection / blinking, accepted STOP solid red, English UI, original JPEG and model BMP capture, raw diagnostic candidate and distance calibration.

## Model integrity and compatibility
New uploaded model-parameters and quantization files are retained byte-for-byte. The generated model CPP receives only marked scheduling/O3 blocks; removing them reconstructs the uploaded CPP exactly. The original weights were not substituted. SDK compatibility patches for ESP32 core 1.0.4 and the raw diagnostic hook are retained. Deployment-version checks reject the old library at compilation.
See Arduino_Libraries/model_identity.json for source hashes and build_validation/ESP32_FAST15_compile.log for actual build size. Build success does not verify live accuracy or improved detection distance.

## Actual compile output
```text
Sketch uses 1673378 bytes (53%) of program storage space. Maximum is 3145728 bytes.
Global variables use 64064 bytes (19%) of dynamic memory, leaving 263616 bytes for local variables. Maximum is 327680 bytes.
```
