# FAST16：160×160 模型接入

此包接入上传的 Edge Impulse Arduino v1.0.5 / deployment 5 模型。实际输入为 int8 RGB `[1,160,160,3]`，输出 `[1,525,5]`，YOLO-Pro 单类别 `3` 映射为 STOP。保留原始权重、量化参数和内部 50% 候选阈值。

## 编译结果

ESP32 已编译通过：程序 1,674,470 / 3,145,728 字节（53%），静态全局变量 64,064 / 327,680 字节（19%）。能够装入当前 4MB Flash / Huge APP 配置；运行时仍需要启用并实际具备 PSRAM。

## 安装

1. 关闭 Arduino IDE，将旧 `A2_StopSign_YOLO_104` 库移出 Arduino libraries 目录，避免多个版本同时存在。
2. 重新打开 IDE，通过 Add .ZIP Library 安装本包 `Arduino_Libraries/A2_StopSign_YOLO_104.zip`。库目录名保留兼容名称，实际版本为 1.0.5。
3. 打开 `ESP32_Assignment2/ESP32_Assignment2.ino`。选择 ESP32 Dev Module、ESP32 core 1.0.4、Huge APP、4MB Flash、PSRAM Enabled、240MHz。摄像头引脚沿用现有 ELEGOO/M5STACK_WIDE 配置。
4. 上传 ESP32。若 UNO 已使用 FAST13 或更新版，无需重复上传；更早版本需要本包 UNO 程序才能使用红色闪烁/STOP 长亮协议。
5. 浏览器刷新后确认 `YOLO FAST 16` 和 `Model v5 / 160×160`。旧模型库会触发编译错误，不能混用。

## 本次改动

- 用统一的 ModelShape 常量同步模型像素数 25,600、RGB 缓冲区 76,800 字节、JPEG 采样、裁剪/letterbox、检测框坐标与推理 signal。
- 同一帧截图中的模型输入 BMP 改为 160×160；原图仍保留摄像头 JPEG。诊断框坐标空间为 `model_160x160`，网页画布同步更新。
- 正常 ESP32 分支的 EON arena 为 257,168 字节，分配时另加 17 字节对齐开销。内部 RAM 不足时自动用 PSRAM；这不是 Arduino 编译报告中的静态 RAM 数值。
- 保留旧核心兼容修复、卷积优化、层间让出 CPU、原始候选分数观察功能。
- 保留红色独立检测、STOP 指示优先、异步分辨率切换及失败回退、英文网页、截图和标定。UNO 源码与 FAST15 相同。

## 上板验证

先用默认 CIF、Centre crop、Preview OFF；保持原来的阈值。检查 `ai_error=0`、`nn_ms`、`cycle_ms` 和串口的 arena 分配信息。分别在 20/30/40/50 cm 保存 JPEG、160×160 BMP 和 metadata，对比停车牌在模型输入中占多少像素与 Raw top score。

相同取景范围下，160 相比 96 的边长增加约 1.67 倍，输入像素数增加约 2.78 倍；这不是识别准确率或运行速度的保证。摄像头切换至更高分辨率后，模型输入仍为 160×160。当前解码流程先把分析图控制在每边不超过 400 像素，因此更高摄像头分辨率不会直接变为更大模型输入。

本次没有实体硬件，不能确认实际帧率、供电稳定性和识别准确率。新模型可能明显更慢。现有时效规则保留：电机视觉数据仅接受采集后 2 秒内的结果，STOP 指示发送要求采集后不足 5 秒，UNO 长亮状态 4.5 秒未刷新即过期。若新模型推理过慢，网页有结果而指示灯不长亮或间歇长亮，也可能是结果超时；请保留串口日志和 `nn_ms/cycle_ms`，不要直接放宽电机时效保护。

## 验证范围

ESP32 编译结果和软件测试记录见 `build_validation/FAST16_validation.txt`。模型源文件 SHA-256 与补丁说明见 `Arduino_Libraries/model_identity.json`。旧版说明与旧编译日志均属历史记录。UNO 本轮未修改，也未执行 AVR 整体编译。
