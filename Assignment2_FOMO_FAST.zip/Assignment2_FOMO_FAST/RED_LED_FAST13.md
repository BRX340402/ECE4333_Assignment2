# FAST 13: red warning and STOP indication

## Behavior
- A connected red region at or above the selected pixel minimum: red LED blinks, 250 ms on / 250 ms off.
- An accepted STOP detection at the applied display threshold (70% default): red LED stays on and overrides blinking.
- A completed negative STOP result releases solid mode; current red detection can resume blinking.
- No fresh red/STOP: manual LED color, which is off at startup.
- Red alone does not affect motors. The existing motor guard policy, distance calibration and 80% motor confidence condition are unchanged.

## Install: BOTH boards need this update
1. Upload UNO_Assignment2/UNO_Assignment2.ino to Arduino Uno using the bundled compatible FastLED/Servo libraries if needed. Do not install the ESP32 model library for the Uno.
2. If FAST12 was installed, keep its A2_StopSign_YOLO_104 library. If upgrading from FAST11 or earlier, replace that model library with Arduino_Libraries/A2_StopSign_YOLO_104.zip from this package.
3. Upload ESP32_Assignment2/ESP32_Assignment2.ino to ESP32 Dev Module, core 1.0.4, Huge APP, 4MB, PSRAM Enabled, CPU 240MHz.
4. Refresh http://192.168.4.1/ and verify YOLO FAST 13. Red detection defaults ON. Preview defaults OFF.

## Check while stationary
- Disable AI detection; show a red object. Red status should change and the LED should blink independently of YOLO.
- Remove it; blinking should stop after the next red frame (or the freshness timeout).
- Enable AI and show a STOP sign large enough for the model. An accepted STOP should produce solid red. Raw diagnostic candidates do NOT count.
- Remove the STOP while leaving a different red object: after a negative STOP result, the light should return to blinking.
- Unplug/disconnect camera communication: red indication expires after 1.2 seconds without a current heartbeat; solid indication expires after 4.5 seconds without a new accepted STOP report.
- Reduce Minimum red pixels if a small red object is missed; increase it if noise triggers blinking. Default: 12 pixels in the largest connected region. It is not a model confidence threshold. Red can be any object, including clothing or background.

## Implementation
Red analysis is a separate task. It uses JPEG-decoded RGB over the full image, with decoder scaling only when a side exceeds 400 pixels. Thus CIF uses 400x296 rather than the 96x96 YOLO input. Hue +/-20 degrees, saturation >=45%, value >=60/255. A 4x4 cell grid retains red-pixel counts; connected 8-neighbor cells with >=2 red pixels form regions. The largest region must meet the user pixel minimum.
The camera buffer is copied for YOLO and returned promptly so the red task can acquire new frames during neural-network computation. Camera access, decoder access and published state are synchronized. Red analysis pauses 150 ms between iterations; actual cycle time includes capture, decoding and scheduling and has not been measured on hardware. Additional decoding may increase YOLO time.
ESP32 sends a separate N=203 red indicator heartbeat every 200 ms from the serial-owning loop. UNO generates the blink locally. This keeps serial messages intact and avoids waiting for YOLO to toggle the LED.
The accepted STOP O flag drives indication; it is independent of the motor-validity flag and does not alter motor guard rules.
UI red frames are asynchronous to YOLO frames; red boxes are not drawn on older YOLO snapshots. Original JPEG, model BMP, raw diagnostics, resolution controls and calibration remain available. All UI text is English.

## Validation
ESP32 core 1.0.4 compiled: 1,666,922 / 3,145,728 bytes flash; 64,016 bytes static RAM.
Host C++ checks passed for red color rejection/acceptance, connected region selection, blink phase, repeated heartbeat, STOP priority, negative result release, stale timeouts and millis rollover.
Mock browser checks passed for red status, enable toggle, pixel minimum, retained diagnostics, capture, threshold and calibration flows.
UNO target compilation was NOT completed: AVR toolchain absent and download blocked by unavailable network. Earlier compile_uno.txt belongs to a prior release. No FAST13 physical board validation has been performed.
