# FAST13 additions

ESP32 -> UNO: {"N":203,"R":0|1} is a red-region indicator heartbeat. Expires after 1200ms. N=200 O=1 now means an accepted STOP at the configured display threshold, for LED indication only; motor P/V/R policy is unchanged. STOP LED timeout is 4500ms, negative reports clear it immediately. UNO N=210 LED values: 0 idle/manual, 1 blinking red, 2 solid red.

FAST 7: official APP TCP100 and webpage driving panel removed. UART protocol below is retained for UNO red LED, telemetry and emergency stop.

# ESP32 ↔ UNO通信（9600 baud）
保留原N命令和车控字段。ESP32 USB调试为115200，独立于Serial2 RX33/TX4。

ESP32→UNO N=200：S序号、A AI开启、V用于电机保护的有效且采集后<=2000ms、P置信度0..1000、R视觉距离cm(-1未知)、X/Y中心、W/H框宽高（分析图像素）、O最近完成且有效的STOP检测>=80%。范围支持最大400×400分析图。O只用于指示灯，不代替V保护；旧发送端未提供O时按V处理。

UNO→ESP32 N=210：M模式、B状态原因、G停车保护、T锁存、U超声波cm、L/C/R地面传感器、V电池mV、S舵机角度、Q视觉序号、A/D左右电机；AI最近视觉包AI标志、VF新鲜有效视觉、P置信度千分数、VD视觉距离、LED红色STOP提示状态。

同一字母在不同N包含义不同。UNO保持单行JSON以供ESP32解析，网页/results中的uno包含该状态包。O/LED只代表最近完成的一次检测，不能作为当前瞬时障碍位置证明。
