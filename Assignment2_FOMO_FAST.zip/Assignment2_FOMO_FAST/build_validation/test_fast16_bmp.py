from pathlib import Path
import re, subprocess
from PIL import Image
fw=Path('work/fast16/Assignment2_YOLO_FAST/ESP32_Assignment2')
s=(fw/'ESP32_Assignment2.ino').read_text();adapter=(fw/'AIAdapter.h').read_text()
helper=re.search(r'void bmp32\([^\n]+',s).group(0)
pack=re.search(r'static uint32_t packedPixel\([^\n]+',adapter).group(0)
body=s[s.index('memset(bmp,0,54);'):s.index('   reference=checkSnapshotInput')]
code='#include <cstdint>\n#include <cstring>\n#include <cstdio>\n#include "ModelShape.h"\nbool inputBGR;\n'+pack+'\n'+helper+'\nint main(){uint8_t pixels[MODEL_RGB_BYTES],buffer[54+MODEL_RGB_BYTES];auto rgb=pixels;auto bmp=buffer;for(int y=0;y<MODEL_SIDE;y++)for(int x=0;x<MODEL_SIDE;x++){rgb[3*(y*MODEL_SIDE+x)]=x;rgb[3*(y*MODEL_SIDE+x)+1]=y;rgb[3*(y*MODEL_SIDE+x)+2]=73;}for(int mode=0;mode<2;mode++){inputBGR=mode;'+body+'FILE*f=fopen(mode?"work/fast16/bgr.bmp":"work/fast16/rgb.bmp","wb");fwrite(bmp,1,sizeof(buffer),f);fclose(f);}}'
p=Path('work/fast16/test_bmp.cpp');p.write_text(code)
subprocess.run(['g++','-std=c++11','-I'+str(fw),str(p),'-o','work/fast16/test_bmp'],check=True);subprocess.run(['work/fast16/test_bmp'],check=True)
for mode,name in enumerate(['rgb','bgr']):
 im=Image.open('work/fast16/'+name+'.bmp');assert im.size==(160,160)
 for y in range(160):
  for x in range(160):assert im.getpixel((x,y))==((73,y,x) if mode else (x,y,73))
print('PASS: actual firmware BMP serialization, 160x160 pixels, orientation and both RGB/BGR modes')
