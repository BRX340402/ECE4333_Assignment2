#include <cassert>
#include "RawDiagnostic.h"
int main(){
 recordRawStop("3",.42f,.2f,.3f,.4f,.6f);
 assert(rawDiagnostic.available && rawDiagnostic.count==1 && rawDiagnostic.score==.42f);
 assert(std::fabs(rawDiagnostic.x-32.0f)<.001f && std::fabs(rawDiagnostic.w-32.0f)<.001f);
 recordRawStop("other",.99f,0,0,1,1);assert(rawDiagnostic.count==1);
 recordRawStop("3",.1f,0,0,1,1);assert(rawDiagnostic.score==.42f && rawDiagnostic.count==2);
 recordRawStop("3",.8f,0,0,1,1);assert(rawDiagnostic.score==.8f && rawDiagnostic.w==160);
 recordRawStop("3",NAN,0,0,1,1);assert(rawDiagnostic.count==3);
 rawDiagnostic={};assert(!rawDiagnostic.available && rawDiagnostic.count==0);
 recordRawStop("3",0,0,0,0,0);assert(rawDiagnostic.available && rawDiagnostic.score==0);
}
