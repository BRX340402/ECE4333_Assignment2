#include <cassert>
#include <cmath>
#include "../ESP32_Assignment2/RawDiagnostic.h"
#include "../ESP32_Assignment2/VisionGeometry.h"
int main(){
 for(int y=0;y<20;y++)for(int x=0;x<20;x++)A2_FOMO_RAW_OBSERVER("3",x==19&&y==19?.8f:.1f,x/20.f,y/20.f,(x+1)/20.f,(y+1)/20.f);
 assert(rawDiagnostic.count==400);assert(fabs(rawDiagnostic.x-152)<.001);assert(fabs(rawDiagnostic.w-8)<.001);
 auto v=makeView(400,296,1,500,500);MappedBox b;assert(mapModelBox(v,152,152,8,8,b));assert(b.x1<400&&b.y1<296);
 rawDiagnostic={};A2_FOMO_RAW_OBSERVER("3",.42f,0,0,.05f,.05f);assert(rawDiagnostic.available&&rawDiagnostic.score==.42f);A2_FOMO_RAW_OBSERVER("other",.99f,0,0,1,1);assert(rawDiagnostic.count==1);
}
