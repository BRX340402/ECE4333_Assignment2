#include <cassert>
#include <cstdio>
#include "../ESP32_Assignment2/ResultTiming.h"
#include "../UNO_Assignment2/LedLogic.h"
int main(){
 IndicatorState led;
 const uint32_t captured=1000,completed=captured+5788;
 assert(completed-captured>5000); // screenshot: capture 39, processing 5827
 assert(stopIndicatorReady(true,completed,completed+20,true,false));
 led.setRed(true,completed);led.setStop(true,completed+20);
 // Red heartbeats must never interrupt STOP; cover a 5831 ms cycle.
 for(uint32_t elapsed=0;elapsed<5831;elapsed+=200){led.setRed(true,completed+20+elapsed);assert(led.mode(completed+20+elapsed)==2);assert(led.on(completed+20+elapsed));}
 led.setStop(true,completed+20+5831);assert(led.mode(completed+20+5831+9999)==2);
 led.setRed(true,completed+20+5831+10000);assert(led.mode(completed+20+5831+10000)==1);
 led.setStop(true,20000);led.setRed(true,21000);led.setStop(false,21000);assert(led.mode(21000)==1);
 assert(!stopIndicatorReady(false,100,100,true,false));
 assert(!stopIndicatorReady(true,100,100,false,false));
 assert(!stopIndicatorReady(true,100,100,true,true));
 assert(stopIndicatorReady(true,100,5099,true,false));
 assert(!stopIndicatorReady(true,100,5100,true,false));
 assert(stopIndicatorReady(true,0xfffffff0U,32,true,false));
 led.setStop(true,0xfffffff0U);assert(led.mode(32)==2);assert(led.mode(9984)==0);
 puts("PASS: slow inference result accepted for LED; 5.831s interval stays solid; negative result clears; 10s expiry; disabled/busy/queued-stale suppression; timer wraparound");
}
