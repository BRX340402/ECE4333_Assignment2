#include <cassert>
#include <cstdint>
uint32_t millis(){static uint32_t t=0;return ++t;}
#include "../ESP32_Assignment2/AIAdapter.h"
int analysisW=400,analysisH=296;bool inputBGR=false;ViewMap aiView=makeView(400,296,1,500,500);float aiThreshold=.7;
Box fixture[3]={{"3",.82,80,80,8,8},{"3",.6,32,32,8,8},{"other",.99,0,0,8,8}};int classifierError=0;
int main(){uint8_t px[76800]={};px[0]=1;px[1]=2;px[2]=3;StopPrediction p;assert(inferFrame(px,p));assert(p.count==1&&p.best==.82f);assert(p.box[0].x0==200&&p.box[0].y0==148);float out;assert(signalData(0,1,&out)==0&&out==66051);assert(signalData(25600,1,&out)==-1);inputBGR=true;assert(signalData(0,1,&out)==0&&out==197121);classifierError=7;assert(!inferFrame(px,p)&&p.error==7);}
