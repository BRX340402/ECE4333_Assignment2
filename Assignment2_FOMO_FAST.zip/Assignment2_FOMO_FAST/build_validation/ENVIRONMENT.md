# Current version: FAST18 FOMO
See FAST18_validation.txt. All following version records are historical.

# Current version: FAST17
See FAST17_validation.txt. Earlier records below are historical.

# Current version: FAST16
See FAST16_validation.txt for current results. The sections below are historical and do not describe model v5.

# FAST 11 verification
ESP32 core1.0.4 / GCC5.2 / PSRAM enabled / 240MHz / 4MB Flash / Huge APP.
Final compile PASS: program1657638 bytes of3145728 (52%); static globals63912 bytes (19%).
Camera sampling: 108 synthetic MCU/geometry cases under ASAN+UBSAN. All output model pixels equal the old full-RGB nearest-neighbour path, including small crops and letterbox padding.
UI mock PASS: CIF control, default preview-off, busy-setting retry, frame pairing, emergency stop, calibration and mobile width. Not physical recognition or latency data.
Model identity: model metadata and weights unchanged. Removing marked compiler/scheduling blocks from generated model CPP reproduces original export SHA256.
UNO firmware is byte-identical to previous package; original passing compile log retained. No hardware test of GPIO, UART, LED, camera, internal-RAM availability, inference latency or long-run stability.
Sampling test: g++ -std=c++11 -fsanitize=address,undefined -Istubs -I../ESP32_Assignment2 test_fast_decoder.cpp -o test_decoder
ASAN_OPTIONS=detect_leaks=0 ./test_decoder

FAST 8: original JPEG + 96x96 input BMP snapshots are on-demand and share a snapshot_id. 108 input-check cases pass and a deliberately changed byte is detected. Snapshot UI and Python collection tool tested with mocked HTTP/images. No hardware identification-range claim. Model library ZIP and UNO source bytes unchanged from FAST 7.

FAST 9: threshold queues atomically and applies before next acquire; UI has explicit Apply, requested/actual confirmation, startup default70%. Browser mocked transition80% ->70% tested. Hardware threshold commit not tested here. Model library and UNO unchanged.

FAST 10 browser mock PASS: explicit sample required; frame/width frozen through live changes; 503 retries; persistent success, NVS error feedback; geometry invalidation; clear without detections. Prior threshold/capture/CIF/preview/stop controls pass. Model library and UNO unchanged.

FAST 11: English-only UI and device responses; source scanned for remaining Chinese text. Mobile browser calibration, threshold, capture, CIF, preview and stop regression PASS. English labels fit mobile width.
