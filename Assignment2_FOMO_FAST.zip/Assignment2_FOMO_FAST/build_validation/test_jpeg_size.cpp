#include <cassert>
#include "../ESP32_Assignment2/JpegSize.h"
int main(){
 int w=0,h=0;const uint8_t p[]={255,216,255,224,0,4,0,0,255,192,0,8,8,4,176,6,64,3,255,217};
 assert(jpegSize(p,sizeof(p),w,h)&&w==1600&&h==1200);
 for(unsigned n=0;n<18;n++)assert(!jpegSize(p,n,w,h));
 const uint8_t bad[]={255,216,255,224,255,255,0};assert(!jpegSize(bad,sizeof(bad),w,h));
 const uint8_t sos[]={255,216,255,218,0,8,0};assert(!jpegSize(sos,sizeof(sos),w,h));
 assert(resolutionSize(0,w,h)&&w==160&&h==120);assert(resolutionSize(5,w,h)&&w==400&&h==296);assert(resolutionSize(10,w,h)&&w==1600&&h==1200);assert(!resolutionSize(11,w,h));
}
