#pragma once
#include <stdint.h>
#include <stddef.h>
struct camera_fb_t{uint8_t*buf;size_t len;size_t width,height;};
