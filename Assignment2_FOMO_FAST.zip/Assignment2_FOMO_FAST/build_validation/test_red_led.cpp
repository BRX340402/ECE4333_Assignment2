#include <cassert>
#include <vector>
#include "../ESP32_Assignment2/RedDetector.h"
#include "../UNO_Assignment2/LedLogic.h"
int main(){
 assert(redPixel(220,30,40));assert(!redPixel(20,220,40));assert(!redPixel(20,30,220));assert(!redPixel(220,210,210));assert(!redPixel(40,0,0));assert(!redPixel(220,160,20));
 std::vector<uint8_t> mask(10000);std::vector<uint16_t>q(10000);
 mask[0]=4;mask[1]=7;mask[101]=5;mask[555]=15;mask[999]=1;
 auto r=largestRedRegion(mask.data(),q.data(),400,296);assert(r.pixels==16&&r.x==0&&r.y==0&&r.w==8&&r.h==8);
 IndicatorState l;assert(l.mode(0)==0);l.setRed(true,100);assert(l.mode(100)==1&&l.on(100));assert(!l.on(350));assert(l.on(600));
 l.setRed(true,650);assert(!l.on(850)); // regular heartbeat must not reset phase
 l.setStop(true,850);assert(l.mode(850)==2&&l.on(1100));l.setRed(false,1100);assert(l.mode(1100)==2);
 l.setStop(false,1200);assert(l.mode(1200)==0);
 l.setRed(true,1300);assert(l.mode(1300)==1);assert(l.mode(2500)==0);
 l.setStop(true,3000);assert(l.mode(12999)==2);assert(l.mode(13000)==0);
 l.setRed(true,0xfffffff0U);assert(l.mode(32)==1);assert(l.on(32));
}
