"""Lossless BMP-to-PNG conversion. Requires Pillow; leaves originals untouched."""
from pathlib import Path
import argparse
from PIL import Image
p=argparse.ArgumentParser();p.add_argument('folder',type=Path);a=p.parse_args()
if not a.folder.is_dir():p.error('Input must be a directory')
out=a.folder/'png';out.mkdir(exist_ok=True)
for src in sorted(a.folder.glob('*.bmp')):
 dst=out/(src.stem+'.png')
 if dst.exists():print('Skipped existing:',dst);continue
 with Image.open(src) as im:
  rgb=im.convert('RGB');rgb.save(dst)
  with Image.open(dst) as check:assert check.convert('RGB').tobytes()==rgb.tobytes()
 print(dst)
