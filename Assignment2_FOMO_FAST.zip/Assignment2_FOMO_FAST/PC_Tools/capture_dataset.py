"""Capture paired original JPEG/model-input BMP/metadata. No auto-labeling."""
import argparse, datetime, json, pathlib, time, urllib.request, uuid

def request(host, path, post=False):
    req = urllib.request.Request(host.rstrip('/') + path, data=b'' if post else None)
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.read()

def collect(host, out, count, interval, distance, note):
    root = pathlib.Path(out)
    for sub in ('original', 'model_input', 'metadata'):
        (root / sub).mkdir(parents=True, exist_ok=True)
    session = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '_' + uuid.uuid4().hex[:8]
    for i in range(count):
        target = json.loads(request(host, '/snapshot', True))['id']
        deadline = time.monotonic() + 45
        while True:
            d = json.loads(request(host, '/snapshot'))
            if d['id'] >= target:
                if d['id'] != target or not d['ready']:
                    raise RuntimeError(d.get('error') or 'Snapshot was replaced by another client')
                break
            if time.monotonic() > deadline:
                raise TimeoutError('Snapshot timeout; check camera and serial monitor')
            time.sleep(.25)
        suffix = '?id=' + str(target)
        # Firmware rejects stale IDs if another client replaces the snapshot.
        jpg = request(host, '/capture' + suffix)
        bmp = request(host, '/model-input' + suffix)
        meta = json.loads(request(host, '/snapshot-meta' + suffix))
        if meta['snapshot_id'] != target or not jpg.startswith(b'\xff\xd8') or not bmp.startswith(b'BM'):
            raise RuntimeError('Invalid image or snapshot identity')
        meta['capture_session'] = session
        meta['measured_distance_cm'] = distance
        meta['user_note'] = note
        meta['annotation_warning'] = 'objects are model predictions, NOT training labels; annotate manually'
        name = f'{session}_{i:04d}'
        # New session ID prevents silent overwrites between capture runs.
        (root / 'original' / (name + '.jpg')).write_bytes(jpg)
        (root / 'model_input' / (name + '.bmp')).write_bytes(bmp)
        (root / 'metadata' / (name + '.json')).write_text(json.dumps(meta, indent=2), encoding='utf-8')
        print(f'{i+1}/{count}: {name}, frame={meta.get("seq")}, input_check={meta.get("input_reference_match")}')
        if i + 1 < count:
            time.sleep(interval)

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--host', default='http://192.168.4.1')
    p.add_argument('--out', default='camera_dataset')
    p.add_argument('--count', type=int, default=30)
    p.add_argument('--interval', type=float, default=2, help='Seconds AFTER each capture finishes')
    p.add_argument('--distance-cm', type=float, default=None, help='Measured value, not AI estimate')
    p.add_argument('--note', default='')
    a = p.parse_args()
    if a.count < 1 or a.interval < 0:
        p.error('count must be positive and interval nonnegative')
    collect(a.host, a.out, a.count, a.interval, a.distance_cm, a.note)
