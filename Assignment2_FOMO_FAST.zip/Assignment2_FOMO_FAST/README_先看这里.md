# FOMO FAST19 — 数值输出恢复

压缩包和解压后的主目录统一命名为 Assignment2_FOMO_FAST；网页显示 FOMO FAST19。

本次只需要上传 ESP32_Assignment2/ESP32_Assignment2.ino，UNO 与 v1.0.6 FOMO 模型库无需重装。保持 core1.0.4、Huge APP、PSRAM Enabled、4MB、240MHz。

## 查看数值

Arduino IDE 打开 ESP32 对应端口的 Serial Monitor 或 Serial Plotter，波特率 115200。默认输出每次推理一行的带标签数值：

Valid:1  STOP:1  Confidence_pct:82.4  Raw_pct:85.2  CellWidth_px:16  CellHeight_px:16  Distance_cm:-1  Inference_ms:850  AI_error:0

此行只是格式示例，不是本板实测性能。实际字段用制表符分隔。

- Valid：图像及推理是否有效，1/0。
- STOP：是否有超过网页阈值的 STOP，1/0；未检测到也继续输出。
- Confidence_pct：已接受的最高 STOP 分数，未接受时为0。
- Raw_pct：最高原始 FOMO 单元分数，可用于观察低于阈值的结果。
- CellWidth_px / CellHeight_px：映射到分析图的 FOMO 区域范围，并非停车牌实际尺寸。
- Distance_cm：-1 表示距离未知。FOMO 没有实际物体边界，尺寸测距仍不可用。
- Inference_ms：本次推理耗时，毫秒。
- AI_error：0 正常，其余为模型错误码。

启动和异常时串口仍会显示诊断文字。若需要完整 JSON（对象列表等），将 Config.h 中 A2_SERIAL_MODE 从1改为2并重新上传；0为多行文字，1为数值绘图，2为JSON。

串口数值来自 ESP32 的 USB/下载器串口。UNO 使用独立串口协议控制灯光，仍为红色闪烁、STOP 长亮。

# FOMO FAST 18 — 接入新 FOMO 模型 v1.0.6

必须安装本包 **A2_StopSign_FOMO_104.zip（v1.0.6）** 并上传 ESP32。若 UNO 已是 FAST17，无需更新；否则上传包内 UNO 程序。设置仍为 core1.0.4 / Huge APP / PSRAM Enabled / 4MB / 240MHz。

保留红色闪烁、STOP 长亮、160×160 截图、英文网页与异步分辨率切换。FOMO 网格不能代表实际物体大小，因此距离和尺寸标定暂不可用，避免错误测距。详见 FOMO_FAST18.md。

以下为历史版本说明，当前要求以 FAST18 为准。

# YOLO FAST 17 — 修正慢推理时 STOP 不长亮

**本次必须同时上传 ESP32 和 UNO 程序。** 已安装 FAST16 的 v1.0.5 模型库无需重装。

STOP 指示从识别完成开始计时；UNO 长亮保持时间改为 10 秒，每次 STOP 结果刷新，覆盖当前约 5.8 秒的推理周期。下一次无 STOP 结果会清除长亮。电机数据时效规则不变。安装及验证步骤见 STOP_LED_FAST17.md。

以下是历史版本记录，当前升级要求以 FAST17 为准。

# YOLO FAST 16 — 160×160 新模型 v5

已完整适配上传的 v1.0.5 模型。**必须替换包内模型库并重新上传 ESP32**；已使用 FAST13 或更新版 UNO 的用户无需更新 UNO。保留红色闪烁、STOP 长亮、英文网页、分辨率切换、截图和标定。

编译通过：Flash 1,674,470 字节（Huge APP 的 53%）；静态 RAM 64,064 字节。

设置：ESP32 Dev Module / ESP32 core 1.0.4 / Huge APP / PSRAM Enabled / 4MB / 240MHz。安装和实机验证细节见 MODEL_V5_FAST16.md。新模型可能更慢，尚未实机验证；请检查 nn_ms/cycle_ms，现有结果过期规则仍生效。

以下为历史版本说明；当前安装要求以 FAST16 为准。

# YOLO FAST 15 — 接入新模型 v4

注意：新导出包仍然是 96×96 RGB，不是高分辨率模型；权重和量化参数确实已更新。必须移走旧 A2_StopSign_YOLO_104 库并安装本包新库，再上传 ESP32。已使用 FAST13/14 UNO 程序的不需要更新 UNO。

开发板保持 ESP32 Dev Module / ESP32 core 1.0.4 / Huge APP / PSRAM Enabled / 4MB / 240MHz。网页显示 FAST15 和 Model v4 / 96×96。详情见 MODEL_V4_FAST15.md。

以下为历史版本说明，安装要求以 FAST15 为准。

# YOLO FAST 14 — 分辨率切换修复

FAST13 升级仅需更新 ESP32；UNO 和模型库不变。设置保持 ESP32 Dev Module / 1.0.4 / Huge APP / PSRAM Enabled / 4MB / 240MHz。

刷新确认 FAST14。分辨率选择一次后等待 Resolution applied 和实际 JPEG 尺寸确认。后台暂停红色采集，丢弃过渡帧，验证新分辨率，失败尝试恢复原分辨率。不要连续反复切换。英文 UI、红色闪烁、STOP 长亮、截图和标定均保留。

尚无实机验证。如仍断线，请发 115200 串口中切换前后含重启/异常的完整日志。详细说明见 RESOLUTION_FAST14.md。

以下为历史说明，以 FAST14 为准。

# YOLO FAST 13 — 红色闪烁 / STOP 长亮

本次需要更新 ESP32 和 UNO 两块板。FAST12 用户模型库不用重装；更早版本请安装包内模型库。UI 全英文。详见 RED_LED_FAST13.md。

红色区域达到最小像素数时红灯闪烁；网页接受的 STOP 检测使红灯长亮且优先。YOLO 原始低分诊断框不会触发长亮。无目标时灯默认熄灭。红色检测默认打开，可在关闭 AI 时单独使用。电机控制逻辑未修改。

ESP32 已编译通过；UNO 指示灯逻辑和网页交互测试通过，但缺少 AVR 工具链、无法联网下载，本次没有完成 UNO 整体编译。上车后需实测。

以下为历史版本说明，安装要求以 FAST13 为准。

# YOLO FAST 12 — 原始候选诊断

本次必须重装包内 A2_StopSign_YOLO_104 模型库，并更新 ESP32；UNO 无需更新。模型权重未变。全英文 UI。操作步骤见 DIAGNOSTIC_FAST12.md。

开启 AI，关闭 Preview，固定 CIF / Centre crop / 70%。在20、30、40、50 cm各截图，查看 Raw top score 和同一截图的黄色候选框，保存 JPEG、BMP、JSON。低分框只是诊断，不会用于停车或标定。

以下为历史版本说明，升级安装要求以本页顶部及 DIAGNOSTIC_FAST12.md 为准。

# YOLO FAST 11 — 停车牌低开销版本

## FAST 11：全英文网页
按钮、操作说明、选中目标、保存/清除成功、忙时重试和错误提示均为英文。保留所有FAST 10功能。只需重新上传ESP32，UNO与模型库无需更新。

## FAST 10：恢复清除标定与明确的操作反馈
从FAST 9升级只需重新上传ESP32程序，UNO与模型库不变，不用重新训练。请刷新网页，确认标题为YOLO FAST 11。
1. 固定停车牌和相机，等待出现完整STOP框；需要查看画面时打开Preview。
2. Distance calibration中选择目标，点击Sample selected object（采样选中目标）。页面明确显示锁定的帧号、目标编号、位置、宽高、得分；有对应预览时显示冻结图片与黄色框。
3. “尺寸采样成功”只代表已选中尺寸，尚未保存标定。后续检测框变动不会替换已锁定宽度。
4. 输入采样时镜头到牌面的实测距离cm（5–1000整数），点击Save calibration。
5. 等待绿色“标定保存成功，设备已确认写入并断电保留”。推理忙时显示正在重试；请求或写入出错显示红色“未确认成功”，不会静默当作成功。
6. Clear calibration可以在没有检测目标时使用。绿色“清除成功”才代表设备确认清除；随后需重新标定才能估距。清除也跨断电保存。
7. 换目标请点“重新选择”；分辨率/裁剪等导致几何版本变化时旧采样失效，需重新采样。保存和清除提示不会被普通检测刷新覆盖；当前K另按帧显示，可能落后于刚完成的操作一帧。
以上是网页交互修复，不改变模型识别精度或推理速度。实体板上的NVS和网络仍需用户现场验证。

## FAST 9：修正阈值应用
用户两份实测JSON候选得分0.7598，但实际threshold仍0.80；这两帧没有应用输入框填写的新值。旧界面只在change事件提交，旧接口争用长推理锁，且没有逐帧显示实际阈值；仅凭JSON无法确定是哪一步提交失败。
默认检测展示阈值改为70%。Camera中输入50–99的整数，点击Apply threshold或按Enter；请求排队，由下一帧开始时应用，期间停止小车。页面Applied to frame必须显示70%/60%才算该帧已生效。模型计算及权重未变。
修改不写入NVS，重启回到70%。设置只影响网页候选过滤；UNO红灯/停车条件仍80%，电机2000ms新鲜度条件不变。
FAST 7/8升级仅上传ESP32程序，无需重装模型库或重刷UNO。电脑Failed to fetch原因尚未确定；本次默认70%可在不提交网页设置时运行，不代表电脑连接问题已修复。

## 保留：按需截图
网页 Training photos → Capture new frame → Save original JPEG / Save model input BMP / Save metadata。无需打开Preview，也无需模型先识别成功。截图请求会发送小车停止命令。截图时才复制原图、生成BMP并进行独立输入校验，不在普通检测循环持续生成。
只需更新ESP32程序；与FAST 7相比模型库和UNO未变。如果从更早版本升级，仍按下述步骤安装包内模型库。
完整采集和训练步骤见 CAMERA_TRAINING_CN.md。

## FAST优化保留
- 完全移除人脸模型及控制、四色像素识别、相机黑线扫描、MJPEG连续视频、官方APP TCP100转发、持续图片样本生成和网页手动车控面板。
- 保留YOLO停车牌识别、位置/宽高、标定估距、ESP32分行串口、UNO红灯、网页紧急停止、CIF及分辨率/白平衡/翻转/阈值/裁剪设置。
- 模型仍是上传的1.0.3、96×96 int8 YOLO-Pro，类别“3”。没有重新训练或修改权重。
- 每帧固定等待350ms改成10ms，减少340ms人为间隔。这不会使NN推理本身自动减少340ms。
- JPEG解码直接选取96×96模型像素，取消400×400全幅RGB、颜色mask和flood-fill队列；减少约1.28MB图像缓冲。CIF拍照仍400×296，坐标仍回映到原分析坐标。
- 取消每帧生成BMP与重复JPEG预览副本。网页预览默认关闭；勾选后仅显示已完成分析的配对图像与框，500ms轮询无并发积压。关闭网页可进一步减少HTTP负载。
- 推理移到core1，Wi-Fi通常运行core0；算子之间每约50ms检查并让出1个RTOS tick。保留看门狗和调度，不做超频。
- YOLO生成代码、卷积、深度卷积编译单元使用GCC O3，不启用fast-math。旧core兼容补丁保留。
- 启动时尝试给169872字节arena预留内部RAM（另有17字节对齐开销）；仅在能留下80KiB内部堆时使用，否则回退PSRAM。每次SDK释放arena时归还到专用池，不反复向系统申请该大块。网页/串口明确显示实际使用哪种内存。小型推理辅助分配仅在内部堆充足时放内部RAM。

## 安装：ESP32需要重新上传
1. 关闭Arduino IDE，把Documents/Arduino/libraries/A2_StopSign_YOLO_104旧目录移到libraries之外备份。
2. IDE → 加载库 → 添加ZIP库，安装本包Arduino_Libraries/A2_StopSign_YOLO_104.zip。本次库包含O3与调度改动，不能只换ino。
3. 打开ESP32_Assignment2/ESP32_Assignment2.ino，保留同目录全部文件。
4. ESP32 Dev Module；esp32 by Espressif Systems **1.0.4**；PSRAM Enabled；CPU 240MHz；Flash 4MB；Huge APP (3MB No OTA/1MB SPIFFS)。保持原相机CAMERA_MODEL_M5STACK_WIDE、XCLK10MHz。
5. 上传ESP32。UNO源码未改：如果已安装上一YOLO版本含O字段红灯协议的UNO程序，不需重刷；否则上传本包UNO程序。FastLED3.2.10、Servo1.2.2包内提供。
6. Wi-Fi ECE4333_A2_V2 / 12345678，浏览器http://192.168.4.1/并强制刷新。应显示YOLO FAST 11。USB串口115200。

## 如何比较延迟
保持同一停车牌、光线、距离、CIF和裁剪设置，观察至少20帧。
- NN：模型执行耗时。若仍约2000ms，模型计算仍是主要瓶颈；删除网页/人脸不能保证解决。
- DSP：模型输入处理时间。
- Decode：JPEG解码与选取96×96像素。
- Processing：本帧采集、解码、推理、组装目标的耗时，不含随后网页JSON/可选JPEG复制和串口打印。
- Previous cycle：上一轮开始到本轮开始的间隔，包含打印、复制及10ms等待，更接近持续检测更新间隔；首帧为0。
- Arena：internal RAM或PSRAM，确认优化是否实际启用。
先关闭Preview测试，再打开比较。若推理仍不够快，需要更轻的模型/更强的处理器；此包没有宣称已经达到某个实体硬件延迟。
Config.h中A2_INTERNAL_ARENA设0可强制PSRAM作为对照。若内部RAM模式出现启动/内存问题，用0重编译。必须比较实际NN耗时和稳定性。

## 尺寸、距离与红灯
STOP框直接来自YOLO，颜色识别已删除，不再参与尺寸判断。小框/边缘裁切框仍不用于标定。
同一实体牌与相机设置下，用尺子量镜头到牌面距离，在页面选择目标并采样，填写cm，再点击Save calibration，等绿色成功提示。成功存NVS并跨断电保留；沿用stop_yolo1键。模型与坐标映射未改，因此相同设置下旧YOLO标定可继续用；实际应复核距离。
UNO红灯仍由有效STOP结果的O字段触发，不要求距离已标定。未检测/关闭AI清除，无新包超过2500ms也清除。原V字段2000ms新鲜度及电机保护未放宽；2秒以上结果可能红灯亮但VF为0。
网页手动车控面板与APP转发已删除；后端既有UNO控制协议保留以免改变急停/看门狗语义。UNO硬件循迹/避障程序不参与ESP32图像循环，本次无需删除它们。

## 功能取舍与验证
这是一份按要求专门精简的停车牌版本，不再满足此前“全部功能保留”的范围，也不包含Assignment 1的人脸演示。
编译和测试记录见build_validation。108组取样测试验证新解码回调与旧方式选取的像素一致；浏览器模拟验证CIF设置、忙时重试、默认关闭预览、配对框、标定与急停。没有实体板，因此不能把这些测试说成真实速度、精度、LED或完整运行稳定性测试。
